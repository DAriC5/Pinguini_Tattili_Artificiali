import time
import serial
import queue

class letturadati():
    def __init__(self, porta_seriale="COM6", baudrate=115200):
        self.message = None
        self.porta_seriale = porta_seriale
        self.baudrate = baudrate
        self.seriale = None
        self.coda = queue.Queue()  # Utilizza una coda interna
        self.avvia_lettura()

    def avvia_lettura(self):
        """Avvia la lettura dei dati dalla porta seriale in un ciclo continuo."""
        try:
            self.seriale = serial.Serial(self.porta_seriale, self.baudrate)
            while True:
                data = self.seriale.readline().decode().strip()
                self.coda.put(data)
                time.sleep(0.1)  # Ritardo per evitare sovraccarico
        except serial.SerialException as e:
            print(f"Errore di comunicazione seriale: {e}")
        except Exception as e:
            print(f"Errore durante la lettura: {e}")

    def mainLettura(self):
        """Legge e restituisce un messaggio dalla coda."""
        try:
            self.message = self.coda.get(timeout=1)  # Attende un messaggio con timeout
            self.coda.task_done()
            return self.message
        except queue.Empty:
            return None  # Restituisce None se la coda è vuota

    def chiudi_comunicazione(self):
        """Chiude la connessione seriale."""
        if self.seriale:
            self.seriale.close()