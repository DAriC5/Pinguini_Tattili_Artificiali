import serial
import threading
import time

class LetturaDati(threading.Thread):
    def __init__(self, porta_seriale="COM6", baudrate=115200, timeout=1):
        threading.Thread.__init__(self, daemon=True)  # Crea thread come daemon
        self.porta_seriale = porta_seriale
        self.baudrate = baudrate
        self.timeout = timeout
        self.seriale = None
        self.running = False
        self.data_lock = threading.Lock()
        self.ultimo_dato = None
        self.connetti()
    
    def connetti(self):
        # """Stabilisce la connessione seriale con timeout."""
        # try:
        #     self.seriale = serial.Serial(
        #         port=self.porta_seriale,
        #         baudrate=self.baudrate,
        #         timeout=self.timeout
        #     )
        #     print(f"Connessione stabilita su {self.porta_seriale}")
        #     return True
        # except serial.SerialException as e:
        #     print(f"Impossibile aprire la porta {self.porta_seriale}: {e}")
        #     return False
        None

    def run(self):
        # """Metodo principale del thread che legge continuamente dalla porta seriale."""
        # self.running = True
        # while self.running:
        #     if not self.seriale or not self.seriale.is_open:
        #         print("La porta seriale non è aperta. Tentativo di riconnessione...")
        #         if not self.connetti():
        #             time.sleep(1)  # Pausa prima di riprovare
        #             continue
                    
        #     try:
        #         if self.seriale.in_waiting > 0:  # Verifica se ci sono dati disponibili
        #             data = self.seriale.readline().decode().strip()
        #             with self.data_lock:
        #                 self.ultimo_dato = data
        #         time.sleep(0.01)  # Piccola pausa per evitare di sovraccaricare la CPU
        #     except serial.SerialException as e:
        #         print(f"Errore di comunicazione seriale: {e}")
        #         self.seriale.close()
        #         self.seriale = None
        #         time.sleep(1)  # Pausa prima di riprovare
        #     except Exception as e:
        #         print(f"Errore durante la lettura: {e}")
        #         time.sleep(0.5)  # Pausa più breve
        None
    
    def mainLettura(self):
        """Recupera l'ultimo dato letto dal thread."""
        # with self.data_lock:
        #     return self.ultimo_dato
        data="0,0,0"
        return data
    
    def chiudi_comunicazione(self):
        """Ferma il thread e chiude la connessione seriale."""
        self.running = False
        if self.seriale and self.seriale.is_open:
            self.seriale.close()
            print(f"Connessione su {self.porta_seriale} chiusa.")
        self.join(timeout=1)  # Attende che il thread termini