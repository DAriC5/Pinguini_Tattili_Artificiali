import pygame
import math
import joblib

class Pinguino(pygame.sprite.Sprite):
    larghezza_schermo = 0
    altezza_schermo = 0

    def __init__(self, dimensione_schermo, immagine1, immagine2, schermo, modello_dx_sx, modello_su_giu, x, y, tipo):
        pygame.sprite.Sprite.__init__(self)
        self.dimensione_schermo = dimensione_schermo
        self.larghezza_schermo = 142 * dimensione_schermo
        self.altezza_schermo = 75 * dimensione_schermo
        
        # Salviamo solo due immagini per l'animazione
        self.immagini = [immagine1, immagine2]
        self.indice_animazione = 0  # Indice per tenere traccia dell'immagine corrente
        self.contatore_animazione = 0  # Contatore per gestire la velocità dell'animazione
        self.velocita_animazione = 10  # Ogni quanti frame cambiare l'immagine
        
        # Impostiamo l'immagine iniziale
        self.image = self.immagini[self.indice_animazione]
        
        self.schermo = schermo
        self.modello_dx_sx = modello_dx_sx
        self.modello_su_giu = modello_su_giu
        self.x = x
        self.y = y
        
        # Parametri per il movimento
        self.velocita_movimento = dimensione_schermo  # Velocità di movimento tra tessere (modificabile)
        self.in_movimento = False  # Flag per indicare se il pinguino si sta spostando
        self.destinazione_x = x  # Coordinate di destinazione
        self.destinazione_y = y
        self.angolo = 0  # Angolo iniziale
        
        # Calcola la dimensione della tessera in base al dimensione_schermo
        self.dimensione_tessera = dimensione_schermo * 2  # Valore approssimativo, adattalo in base al tuo gioco
        
        self.velocita = dimensione_schermo / 5
        self.rotazione = dimensione_schermo / 1
        self.accellerazione = dimensione_schermo / 10
        self.bordo = -10
        
        self.mask = pygame.mask.from_surface(self.image)
        self.tipo = tipo
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        if tipo == 1 or tipo == 4:
            self.colore = "rossa"
            self.angolo = 0
        else:
            self.colore = "verde"
            self.angolo = 3.15
    
    def aggiorna_animazione(self):
        """Gestisce il ciclo di animazione dei frame del pinguino"""
        # Incrementiamo il contatore solo se il pinguino si sta muovendo
        if self.in_movimento:
            self.contatore_animazione += 1
            
            # Quando il contatore raggiunge la velocità di animazione, cambiamo frame
            if self.contatore_animazione >= self.velocita_animazione:
                self.contatore_animazione = 0  # Resettiamo il contatore
                self.indice_animazione = (self.indice_animazione + 1) % len(self.immagini)  # Passiamo al frame successivo ciclicamente
        else:
            # Se il pinguino è fermo, usiamo il primo frame
            self.indice_animazione = 0
            self.contatore_animazione = 0

    def posiziona_immagine(self, schermo, x, y, angolo):
        """Posiziona e ruota l'immagine al centro delle coordinate specificate."""
        # Otteniamo l'immagine corrente dall'array delle immagini
        immagine_corrente = self.immagini[self.indice_animazione]
        
        angolo_immagine = angolo - 200
        immagine_ruotata = pygame.transform.rotate(immagine_corrente, math.degrees(angolo_immagine))
        immagine_rect = immagine_ruotata.get_rect(center=(x, y))
        self.rect = immagine_rect
        self.image = immagine_ruotata
        schermo.blit(immagine_ruotata, immagine_rect)
        return immagine_ruotata
    
    def calcola_angolo_verso_posizione(self, x_target, y_target):
        """Calcola l'angolo necessario per guardare verso una determinata posizione"""
        dx = x_target - self.x
        dy = self.y - y_target  # Invertito a causa del sistema di coordinate di pygame
        
        # Calcola l'angolo in radianti
        if dx == 0:
            return math.pi/2 if dy > 0 else 3*math.pi/2
        
        angolo = math.atan2(dy, dx)
        
        # Assicurati che l'angolo sia tra 0 e 2π
        if angolo < 0:
            angolo += 2 * math.pi
            
        return angolo
    
    def muovi_verso_tessera(self, x_target, y_target):
        """Muove il pinguino verso le coordinate specificate con la velocità impostata"""
        if not self.in_movimento:
            self.destinazione_x = x_target
            self.destinazione_y = y_target
            self.angolo = self.calcola_angolo_verso_posizione(x_target, y_target)
            self.in_movimento = True
            
    def muovi_sinistra(self):
        """Muove il pinguino sulla tessera alla sua sinistra"""
        if not self.in_movimento:
            # Calcola la posizione della tessera a sinistra
            x_target = self.x - self.dimensione_tessera
            y_target = self.y
            self.muovi_verso_tessera(x_target, y_target)
    
    def muovi_destra(self):
        """Muove il pinguino sulla tessera alla sua destra"""
        if not self.in_movimento:
            # Calcola la posizione della tessera a destra
            x_target = self.x + self.dimensione_tessera
            y_target = self.y
            self.muovi_verso_tessera(x_target, y_target)
    
    def muovi_sopra(self):
        """Muove il pinguino sulla tessera sopra di lui"""
        if not self.in_movimento:
            # Calcola la posizione della tessera sopra
            x_target = self.x
            y_target = self.y - self.dimensione_tessera
            self.muovi_verso_tessera(x_target, y_target)
    
    def muovi_sotto(self):
        """Muove il pinguino sulla tessera sotto di lui"""
        if not self.in_movimento:
            # Calcola la posizione della tessera sotto
            x_target = self.x
            y_target = self.y + self.dimensione_tessera
            self.muovi_verso_tessera(x_target, y_target)
    
    def aggiorna_movimento(self):
        """Aggiorna la posizione del pinguino in movimento verso la destinazione"""
        if self.in_movimento:
            # Calcola la distanza dalla destinazione
            dx = self.destinazione_x - self.x
            dy = self.destinazione_y - self.y
            distanza = math.sqrt(dx**2 + dy**2)
            
            if distanza < self.velocita_movimento:
                # Il pinguino ha raggiunto la destinazione
                self.x = self.destinazione_x
                self.y = self.destinazione_y
                self.in_movimento = False
            else:
                # Aggiorna la posizione
                direzione_x = dx / distanza
                direzione_y = dy / distanza
                self.x += direzione_x * self.velocita_movimento
                self.y += direzione_y * self.velocita_movimento
    
    def imposta_velocita(self, velocita):
        """Imposta la velocità di movimento tra le tessere"""
        self.velocita_movimento = velocita
    
    def trova_movimento_dx_sx(self, dati_movimento):
        # Caricamento del modello salvato
        nuovo_movimento = dati_movimento
        risultato = self.modello_dx_sx.predict([nuovo_movimento])
        print("Classe predetta:", risultato[0])
        return risultato[0]

    def trova_movimento_su_giu(self, dati_movimento):
        # Caricamento del modello salvato
        nuovo_movimento = dati_movimento
        risultato = self.modello_su_giu.predict([nuovo_movimento])
        print("Classe predetta:", risultato[0])
        return risultato[0]

    def gestisci_movimento(self, datiMovimento):
        """Gestisce il movimento in base ai controlli forniti"""
        # Se il pinguino è già in movimento, non modificare la destinazione
        if self.in_movimento:
            return
        
        keys = pygame.key.get_pressed()
        if self.tipo == 1:
            if keys[pygame.K_a]:
                self.muovi_sinistra()
            elif keys[pygame.K_d]:
                self.muovi_destra()
            elif keys[pygame.K_w]:
                self.muovi_sopra()
            elif keys[pygame.K_s]:
                self.muovi_sotto()
                
        elif self.tipo == 2:
            if keys[pygame.K_j]:
                self.muovi_sinistra()
            elif keys[pygame.K_l]:
                self.muovi_destra()
            elif keys[pygame.K_i]:
                self.muovi_sopra()
            elif keys[pygame.K_k]:
                self.muovi_sotto()
                
        elif self.tipo == 3:
            movimento_dx_sx = self.trova_movimento_dx_sx(datiMovimento)
            movimento_su_giu = self.trova_movimento_su_giu(datiMovimento)
            
            if movimento_dx_sx == "dxDx":
                self.muovi_destra()
            elif movimento_dx_sx == "sxDx":
                self.muovi_sinistra()
            elif movimento_su_giu == "avDx":
                self.muovi_sopra()
            elif movimento_su_giu == "indDx":
                self.muovi_sotto()
                
        elif self.tipo == 4:
            movimento_dx_sx = self.trova_movimento_dx_sx(datiMovimento)
            movimento_su_giu = self.trova_movimento_su_giu(datiMovimento)
            
            if movimento_dx_sx == "dxSx":
                self.muovi_destra()
            elif movimento_dx_sx == "sxSx":
                self.muovi_sinistra()
            elif movimento_su_giu == "avSx":
                self.muovi_sopra()
            elif movimento_su_giu == "indSx":
                self.muovi_sotto()
    
    def main(self, datiMovimento):
        """Gestisce il movimento e la rotazione dell'immagine"""
        # Prima aggiorniamo l'animazione
        self.aggiorna_animazione()
        
        # Gestiamo il movimento
        self.gestisci_movimento(datiMovimento)
        
        # Aggiorniamo la posizione se in movimento
        self.aggiorna_movimento()
        
        # Poi posizioniamo e ruotiamo l'immagine corrente
        self.posiziona_immagine(self.schermo, self.x, self.y, self.angolo)
        
        # Aggiorniamo la maschera con l'immagine corrente
        self.mask = pygame.mask.from_surface(self.image)