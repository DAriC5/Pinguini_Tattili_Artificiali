import pygame
import csv
import pandas as pd
from navicella import Navicella
from proiettile import Proiettile
from scudo import Scudo
import joblib
import letturaDati
from sklearn import *



def controlla_collisione(navicella1, navicella2):
    """Controlla se questa navicella collide con un'altra navicella."""
    return pygame.sprite.collide_mask(navicella1, navicella2)

def controlla_proiettili(gruppo, navicella):
    for proiettile in gruppo:
        proiettile.main()
        if pygame.sprite.collide_rect(proiettile, navicella ):
            gruppo.remove(proiettile)  # Elimina il proiettile
            navicella.riduci_vite()
        elif(proiettile.x<0 or proiettile.y<0 or proiettile.x>800 or proiettile.y>600):
            gruppo.remove(proiettile)  # Elimina il proiettile
    return gruppo

def salva_dati_pandas(dati, nome_file):
    """Salva i dati in un file CSV utilizzando pandas."""
    try:
        df = pd.DataFrame([dati])  # Crea un DataFrame dal dizionario
        df.to_csv(nome_file, index=False)  # Salva il DataFrame in un file CSV
        print(f"Dati salvati con successo in {nome_file}")
    except Exception as e:
        print(f"Errore durante il salvataggio: {e}")

def main():
    
    
    pygame.init()
    larghezza_schermo = 800
    altezza_schermo = 600

    # Impostazioni della finestra
    schermo = pygame.display.set_mode((larghezza_schermo, altezza_schermo))
    sfondo = pygame.image.load("spazio.png").convert()
    sfondo_ridimensionato = pygame.transform.scale(sfondo, (800, 600))




    # Caricamento dell'immagine
    img_rossa = pygame.image.load("rocketship-a.png")  # Sostituisci con il percorso effettivo
    img_rossa = pygame.transform.scale_by(img_rossa, 0.15)  # Ridimensiona se necessario
    img_verde = pygame.image.load("rocketship-b.png")  # Sostituisci con il percorso effettivo
    img_verde = pygame.transform.scale_by(img_verde, 0.15)  # Ridimensiona se necessario
    immagine_proiettile=pygame.image.load("proiettile.png")
    immagine_proiettile = pygame.transform.scale_by(immagine_proiettile, 0.20) 
    immagine_scudo=pygame.image.load("scudo.png").convert_alpha()
    immagine_scudo=pygame.transform.scale_by(immagine_scudo, 0.2)




    # Colore di sfondo

    modello_su_giu=joblib.load('modello_movimenti.joblib')
    modello_dx_sx=joblib.load('modello_rotazioni.joblib')

    navicellaRossa=Navicella(larghezza_schermo, altezza_schermo, img_rossa, schermo, None, None, x=40, y=40, tipo=1, )
    navicellaVerde=Navicella(larghezza_schermo, altezza_schermo, img_verde, schermo, None, None, x=760, y=560, tipo=2, )

    gruppo_proiettili_rossi = pygame.sprite.Group()
    gruppo_proiettili_verdi = pygame.sprite.Group()


    scudo_rosso= Scudo(larghezza_schermo, altezza_schermo,immagine_scudo,schermo,
                    navicellaRossa.x, navicellaRossa.y, 
                    navicellaRossa.angolo, tipo=1)
    scudo_verde= Scudo(larghezza_schermo, altezza_schermo,immagine_scudo,schermo,
                    navicellaRossa.x, navicellaRossa.y, 
                    navicellaRossa.angolo, tipo=2)
    
    if(navicellaVerde.tipo==3):
        ld = letturaDati.letturadati()  # Crea un'istanza del thread per leggere dalla micro:bit

    datiMovimentoRosso=None
    datiMovimentoVerde=None

    # Ciclo di gioco principale
    in_esecuzione = True
    while in_esecuzione:
        for evento in pygame.event.get():
            if evento.type == pygame.KEYDOWN:  
                if evento.key == pygame.K_c:  # Esempio: spazio per sparare
                    nuovo_proiettile = Proiettile(larghezza_schermo, altezza_schermo,immagine_proiettile,schermo,
                    navicellaRossa.x, navicellaRossa.y, 
                    navicellaRossa.angolo)     
                    gruppo_proiettili_rossi.add(nuovo_proiettile)
                if evento.key == pygame.K_n:  # Esempio: spazio per sparare
                    nuovo_proiettile = Proiettile(larghezza_schermo, altezza_schermo,immagine_proiettile,schermo,
                    navicellaVerde.x, navicellaVerde.y, 
                    navicellaVerde.angolo)     
                    gruppo_proiettili_verdi.add(nuovo_proiettile)
            if evento.type == pygame.QUIT:
                in_esecuzione = False

        # Aggiorna la posizione di tutti i proiettili


    # Pulisci lo schermo
        schermo.blit(sfondo_ridimensionato, (0, 0))

        if(navicellaVerde.tipo==3):
            dati_microbit=ld.mainLettura()
            print(dati_microbit, " il tipo è ", type(dati_microbit))
            if dati_microbit is not None:
                dati_microbit_float = [float(x) for x in dati_microbit.split(",")[:3]]
                print(dati_microbit_float, " il tipo è ", type(dati_microbit_float[0]))
                datiMovimentoVerde=dati_microbit_float
            else:
                print("dati_microbit è None")
        
        

        navicellaRossa.main(datiMovimentoRosso)
        navicellaVerde.main(datiMovimentoVerde)

        scudo_rosso.main(navicellaRossa.x, navicellaRossa.y, navicellaRossa.angolo)
        scudo_verde.main(navicellaVerde.x, navicellaVerde.y, navicellaVerde.angolo)

        gruppo_proiettili_rossi=controlla_proiettili(gruppo_proiettili_rossi, navicellaVerde)
        gruppo_proiettili_verdi=controlla_proiettili(gruppo_proiettili_verdi, navicellaRossa)

        pygame.display.flip()

        dati_gioco = {
            "x_rossa": navicellaRossa.x,
            "y_rossa": navicellaRossa.y,
            "angolo_rossa": navicellaRossa.angolo,
            "velocita_rossa": navicellaRossa.velocita,
            "x_verde": navicellaVerde.x,
            "y_verde": navicellaVerde.y,
            "angolo_verde": navicellaVerde.angolo,
            "velocita_verde": navicellaVerde.velocita
        }

        # salva_dati_pandas(dati_gioco, "dati.csv")


        if navicellaRossa.vite==0:
            vincitore=1
            in_esecuzione=False
        elif navicellaVerde.vite==0:
            vincitore=2
            in_esecuzione=False

    ld.chiudi_comunicazione()
    pygame.quit()  # Chiudi Pygame correttamente
    quit()  # Chi    






# # Inizializzazione di Pygame
if __name__ == "__main__":  # Controlla se lo script è eseguito direttamente
    main()  # Esegue la funzione principale

