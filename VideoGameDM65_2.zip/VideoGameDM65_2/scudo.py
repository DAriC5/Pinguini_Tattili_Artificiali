import pygame
import math

class Scudo(pygame.sprite.Sprite) :
    larghezza_schermo=0
    altezza_schermo=0

    def __init__(self, larghezza_schermo, altezza_schermo, immagine, schermo, x, y, angolo, tipo):
        pygame.sprite.Sprite.__init__(self)
        self.x = x-20
        self.y = y-20
        self.angolo = angolo # Angolo iniziale in radianti
        self.velocita=1
        self.larghezza_schermo=larghezza_schermo
        self.altezza_schermo=altezza_schermo
        self.mask = pygame.mask.from_surface(immagine) 
        self.schermo=schermo
        self.image=immagine
        self.rect = self.image.get_rect()  # Crea il rettangolo *dopo* aver caricato l'immagine
        self.rect.x = x  # Posizione iniziale
        self.rect.y = y
        self.eliminami=0
        self.durata_scudo=1
        self.scudo=0
        self.recupero_scudo=0.1
        self.tipo=tipo
        pass

    def posiziona_immagine(self, schermo, immagine):
        immagine_ruotata = pygame.transform.rotate(immagine, math.degrees(self.angolo))
        self.rect = immagine_ruotata.get_rect(center=(self.x, self.y))  # Imposta il centro del rettangolo
        schermo.blit(immagine_ruotata, self.rect)
    
    def attiva_scudo(self):
        if self.durata_scudo>=0:
            self.scudo=1
        else:
            self.scudo=0
            self.durata_scudo=self.durata_scudo+self.recupero_scudo
    

    def main(self, x, y, angolo):
        """Gestisce il movimento e la rotazione dell'immagine con le frecce."""
    
        self.x=x
        self.y=y
        self.angolo=angolo

        keys = pygame.key.get_pressed()
        if self.tipo==1:
            if keys[pygame.KMOD_SHIFT]:
                self.attiva_scudo()
            else:
                self.scudo=0
                self.durata_scudo=self.durata_scudo+self.recupero_scudo
        if self.tipo==2:
            if keys[pygame.KMOD_RSHIFT]:
                self.attiva_scudo()
            else:
                self.scudo=0
                self.durata_scudo=self.durata_scudo+self.recupero_scudo

        self.posiziona_immagine(self.schermo, self.image )

        self.mask= pygame.mask.from_surface(self.image)
        
        
        
        

            
            


