import pygame
import math
import joblib


class Pinguino(pygame.sprite.Sprite) :

    # angolo=0
    # velocita=0
    # rotazione=0
    larghezza_schermo=0
    altezza_schermo=0

    def __init__(self, dimensione_schermo, immagine1, immagine2, schermo, modello_dx_sx, modello_su_giu, x, y, tipo):
        pygame.sprite.Sprite.__init__(self)
        self.dimensione_schermo=dimensione_schermo
        self.larghezza_schermo = 142*dimensione_schermo
        self.altezza_schermo = 75*dimensione_schermo
        
        # Salviamo solo due immagini per l'animazione
        self.immagini = [immagine1, immagine2]
        self.indice_animazione = 0  # Indice per tenere traccia dell'immagine corrente
        self.contatore_animazione = 0  # Contatore per gestire la velocità dell'animazione
        self.velocita_animazione = 10  # Ogni quanti frame cambiare l'immagine (modifica questo valore per velocizzare/rallentare)
        
        # Impostiamo l'immagine iniziale
        self.image = self.immagini[self.indice_animazione]
        
        self.schermo=schermo
        self.modello_dx_sx=modello_dx_sx
        self.modello_su_giu=modello_su_giu
        self.x = x
        self.y = y
         # Angolo iniziale in radianti
        self.velocita=dimensione_schermo/5
        self.rotazione=dimensione_schermo/1
        self.accellerazione=dimensione_schermo/10
        self.bordo=-10
        
        self.mask = pygame.mask.from_surface(self.image) 
        self.tipo=tipo
        self.rect = self.image.get_rect()  # Crea il rettangolo *dopo* aver caricato l'immagine
        self.rect.x = x  # Posizione iniziale
        self.rect.y = y
        
        if(tipo==1 or tipo==4):
            self.colore="rossa"
            self.angolo = 0
        else:
            self.colore="verde"
            self.angolo = 3.15
        # self.decellerazione=0.05
        pass

    def aggiorna_animazione(self):
        """Gestisce il ciclo di animazione dei frame del pinguino"""
        # Incrementiamo il contatore solo se il pinguino si sta muovendo
        if self.velocita > self.dimensione_schermo/10:  # Solo se si sta muovendo abbastanza velocemente
            self.contatore_animazione += 1
            
            # Quando il contatore raggiunge la velocità di animazione, cambiamo frame
            if self.contatore_animazione >= self.velocita_animazione:
                self.contatore_animazione = 0  # Resettiamo il contatore
                self.indice_animazione = (self.indice_animazione + 1) % len(self.immagini)  # Passiamo al frame successivo ciclicamente
                # Non aggiorniamo ancora self.image perché lo faremo in posiziona_immagine
        else:
            # Se il pinguino è fermo o si muove lentamente, usiamo il primo frame
            self.indice_animazione = 0
            self.contatore_animazione = 0

    def trova_movimento_dx_sx(self, dati_movimento):
        # Caricamento del modello salvato
        # Esempio di nuovo movimento da classificare
        nuovo_movimento = dati_movimento#[-572.0,328.0,784.0]  # x, y e z
        risultato =  self.modello_dx_sx.predict([nuovo_movimento])  # si aspetta un un array con forma (n_samples, n_features)  
        print("Classe predetta:", risultato[0])
                
        return risultato[0]

    def trova_movimento_su_giu(self, dati_movimento):
        # Caricamento del modello salvato
        # Esempio di nuovo movimento da classificare
        nuovo_movimento = dati_movimento#[-572.0,328.0,784.0]  # x, y e z
        risultato =  self.modello_su_giu.predict([nuovo_movimento])  # si aspetta un un array con forma (n_samples, n_features)  
        print("Classe predetta:", risultato[0])
                
        return risultato[0]

    def posiziona_immagine(self, schermo, x, y, angolo):
        """Posiziona e ruota l'immagine al centro delle coordinate specificate."""
        # Otteniamo l'immagine corrente dall'array delle immagini
        immagine_corrente = self.immagini[self.indice_animazione]
        
        angolo_immagine=angolo-200
        immagine_ruotata = pygame.transform.rotate(immagine_corrente, math.degrees(angolo_immagine))  # Ruota l'immagine
        immagine_rect = immagine_ruotata.get_rect(center=(x, y))
        self.rect=immagine_rect
        self.image = immagine_ruotata  # Aggiorniamo self.image con l'immagine ruotata
        schermo.blit(immagine_ruotata, immagine_rect)
        return immagine_ruotata

    def decellera(self, velocita):
        velocita -= self.accellerazione
        # Limita la velocità minima (opzionale)
        velocita = max(velocita, self.dimensione_schermo*1)
        self.velocita_animazione=10
        return velocita

    def accellera(self, velocita):
        velocita += self.accellerazione
        velocita = min(velocita, self.dimensione_schermo*2) 
        self.velocita_animazione=5
        return velocita
    
    def ruota_sx(self, angolo, rotazione):
        angolo = (angolo + math.radians(rotazione)) % (2 * math.pi)  # Rotazione antioraria
        return angolo
    
    def ruota_dx(self, angolo, rotazione):
        angolo = (angolo - math.radians(rotazione)) % (2 * math.pi)  # Rotazione oraria
        return angolo
    
    def calcola_coordinate(self, x, y, angolo, velocita):
        """Calcola le nuove coordinate in base all'angolo e alla velocità."""
        x += velocita * math.cos(angolo)
        y -= velocita * math.sin(angolo)  # Ricorda: l'asse y è invertito in Pygame
        return x, y

    def gestisci_movimento(self, datiMovimento):
        keys = pygame.key.get_pressed()
        if self.tipo==1:
            if keys[pygame.K_w]:
                self.velocita = self.accellera(self.velocita)
            else:
                self.velocita = self.decellera(self.velocita)
            if keys[pygame.K_a]:
                self.angolo = self.ruota_sx(self.angolo, self.rotazione)
            if keys[pygame.K_d]:
                self.angolo = self.ruota_dx(self.angolo, self.rotazione)
            
        elif self.tipo==2:
            if keys[pygame.K_i]:
                self.velocita = self.accellera(self.velocita)
            else:
                self.velocita = self.decellera(self.velocita)
            if keys[pygame.K_j]:
                self.angolo = self.ruota_sx(self.angolo, self.rotazione)
            if keys[pygame.K_l]:
                self.angolo = self.ruota_dx(self.angolo, self.rotazione)

        elif self.tipo==3:
            movimento_dx_sx=self.trova_movimento_dx_sx(datiMovimento)
            if(movimento_dx_sx=="dxDx"):
                self.angolo = self.ruota_dx(self.angolo, self.rotazione)
            elif(movimento_dx_sx=="sxDx"):
                self.angolo = self.ruota_sx(self.angolo, self.rotazione)
            
            movimento_su_giu=self.trova_movimento_su_giu(datiMovimento)
            if(movimento_su_giu=="avDx"):
                self.velocita = self.accellera(self.velocita)
            else:
                self.velocita = self.decellera(self.velocita)

        elif self.tipo==4:
            movimento_dx_sx=self.trova_movimento_dx_sx(datiMovimento)
            if(movimento_dx_sx=="dxSx"):
                self.angolo = self.ruota_dx(self.angolo, self.rotazione)
            elif(movimento_dx_sx=="sxSx"):
                self.angolo = self.ruota_sx(self.angolo, self.rotazione)
            
            movimento_su_giu=self.trova_movimento_su_giu(datiMovimento)
            if(movimento_su_giu=="avSx"):
                self.velocita = self.accellera(self.velocita)
            else:
                self.velocita = self.decellera(self.velocita)

        self.x, self.y = self.calcola_coordinate(self.x, self.y, self.angolo, self.velocita)
        
        # if self.x < self.bordo:
        #     self.x = self.bordo
        # elif self.x > self.larghezza_schermo-self.bordo:
        #     self.x = self.larghezza_schermo-self.bordo
        # if self.y < self.bordo:
        #     self.y = self.bordo
        # elif self.y > self.altezza_schermo-self.bordo:
        #     self.y = self.altezza_schermo-self.bordo

    def main(self, datiMovimento):
        """Gestisce il movimento e la rotazione dell'immagine con le frecce."""
        # Prima aggiorniamo l'animazione
        self.aggiorna_animazione()
        
        # Poi posizioniamo e ruotiamo l'immagine corrente
        self.posiziona_immagine(self.schermo, self.x, self.y, self.angolo)
        
        # Gestiamo il movimento
        self.gestisci_movimento(datiMovimento)
        
        # Aggiorniamo la maschera con l'immagine corrente
        self.mask = pygame.mask.from_surface(self.image)