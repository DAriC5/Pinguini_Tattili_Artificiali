import pygame
import math
import time

class Tessera(pygame.sprite.Sprite):
    def __init__(self, larghezza_schermo, altezza_schermo, immagine, schermo, x, y, angolo):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.larghezza_schermo = larghezza_schermo
        self.altezza_schermo = altezza_schermo
        self.schermo = schermo
        
        print(f"Creazione tessera a ({x}, {y})")
        
        # Controlla se l'immagine è valida
        if immagine is None:
            print("ERRORE: immagine tessera è None!")
            # Crea un'immagine di fallback
            self.original_image = pygame.Surface((50, 50))
            self.original_image.fill((255, 0, 0))  # Rosso per debug
        else:
            self.original_image = immagine
            
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.angolo = angolo
        self.is_sinking = False
        self.is_rising = False
        self.alpha = 255  # Piena opacità
        self.sink_start_time = 0
        self.sink_duration = 2000  # 3 secondi per affondare
        self.rise_delay = 4000     # 2 secondi prima di risalire
        self.rise_duration = 1000  # 3 secondi per risalire
       
    def affonda(self):
        if not self.is_sinking and not self.is_rising:
            self.is_sinking = True
            self.sink_start_time = pygame.time.get_ticks()
   
    def update(self):
        try:
            current_time = pygame.time.get_ticks()
            
            # Per debug, limita la frequenza dei print per non intasare la console
            
            # Gestione dell'affondamento
            if self.is_sinking:
                elapsed = current_time - self.sink_start_time
                if elapsed < self.sink_duration:
                    # Calcolo opacità mentre affonda
                    self.alpha = 255 * (1 - elapsed / self.sink_duration)
                    self.alpha = max(0, min(255, self.alpha))
                else:
                    # Completato l'affondamento
                    self.alpha = 0
                    self.is_sinking = False
                    self.is_rising = True
                    self.rise_start_time = current_time + self.rise_delay
                    print(f"Tessera completamente affondata, risorgerà al tempo {self.rise_start_time}")
            
            # Gestione della risalita dopo il ritardo
            if self.is_rising and current_time >= self.rise_start_time:
                elapsed = current_time - self.rise_start_time
                if elapsed < self.rise_duration:
                    # Calcolo opacità mentre riemerge
                    self.alpha = 255 * (elapsed / self.rise_duration)
                    self.alpha = max(0, min(255, self.alpha))
                else:
                    # Completata la risalita
                    self.alpha = 255
                    self.is_rising = False
            
            # Applica l'opacità all'immagine
            try:
                temp_image = self.original_image.copy()
                temp_image.set_alpha(int(self.alpha))
                self.image = temp_image
            except Exception as e:
                print(f"Errore nell'aggiornamento dell'immagine: {e}")
        except Exception as e:
            print(f"Errore in update() della tessera: {e}")