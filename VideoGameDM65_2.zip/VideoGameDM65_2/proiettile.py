import pygame
import math

class Proiettile(pygame.sprite.Sprite) :


    # angolo=0
    # velocita=0
    # rotazione=0
    larghezza_schermo=0
    altezza_schermo=0

    def __init__(self, larghezza_schermo, altezza_schermo, immagine, schermo, x, y, angolo):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.angolo = angolo # Angolo iniziale in radianti
        self.velocita=1
        self.larghezza_schermo=larghezza_schermo
        self.altezza_schermo=altezza_schermo
        self.mask = pygame.mask.from_surface(immagine) 
        self.schermo=schermo
        self.image=immagine
        self.rect = self.image.get_rect()  # Crea il rettangolo *dopo* aver caricato l'immagine
        self.rect.x = x  # Posizione iniziale
        self.rect.y = y
        self.eliminami=0
        pass

    def posiziona_immagine(self, schermo, immagine):
        immagine_ruotata = pygame.transform.rotate(immagine, math.degrees(self.angolo))  # Ruota l'immagine
        self.rect = immagine_ruotata.get_rect()
        self.rect.x = self.x 
        self.rect.y = self.y
        """Posiziona e ruota l'immagine al centro delle coordinate specificate."""
        schermo.blit(immagine_ruotata, self.rect)
    

    
    def calcola_coordinate(self, x, y, angolo, velocita):
        """Calcola le nuove coordinate in base all'angolo e alla velocità."""
        x += velocita * math.cos(angolo)
        y -= velocita * math.sin(angolo)  # Ricorda: l'asse y è invertito in Pygame
        return x, y

    def gestisci_movimento(self):
        
        self.x, self.y = self.calcola_coordinate(self.x, self.y, self.angolo, self.velocita)
        if self.x < 0:
            self.eliminami=1
        elif self.x > self.larghezza_schermo:
            self.eliminami=1
        if self.y < 0:
            self.eliminami=1
        elif self.y > self.altezza_schermo:
            self.eliminami=1

    def main(self):
        """Gestisce il movimento e la rotazione dell'immagine con le frecce."""
        
        self.gestisci_movimento()

        self.x, self.y=self.calcola_coordinate(self.x, self.y, self.angolo, self.velocita)
          # Crea il rettangolo *dopo* aver caricato l'immagine
        
        self.posiziona_immagine(self.schermo, self.image )

        self.mask= pygame.mask.from_surface(self.image)
        
        
        
        

            
            


