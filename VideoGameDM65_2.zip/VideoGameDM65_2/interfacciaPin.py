import pygame
import pandas as pd
from pinguino import Pinguino
import joblib
from letturaDati import LetturaDati
from sklearn import *
from matriceTessere import MatriceTessere
import time

def controlla_collisione(navicella1, navicella2):
    """Controlla se questa navicella collide con un'altra navicella."""
    return pygame.sprite.collide_mask(navicella1, navicella2)

def salva_dati_pandas(dati, nome_file):
    """Salva i dati in un file CSV utilizzando pandas."""
    try:
        df = pd.DataFrame([dati])  # Crea un DataFrame dal dizionario
        df.to_csv(nome_file, index=False)  # Salva il DataFrame in un file CSV
        print(f"Dati salvati con successo in {nome_file}")
    except Exception as e:
        print(f"Errore durante il salvataggio: {e}")

def mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo):
    """Mostra l'immagine del vincitore e attende 5 secondi."""
    if vincitore == 1:
        # Carica l'immagine del vincitore rosso
        img_vincitore = pygame.image.load("RossoVinto.png")
    else:
        # Carica l'immagine del vincitore verde
        img_vincitore = pygame.image.load("VerdeVinto.png")
    
    # Ridimensiona l'immagine se necessario
    img_vincitore = pygame.transform.scale_by(img_vincitore, dimensione_schermo/10)
    
    # Posiziona l'immagine al centro dello schermo
    posizione_x = (larghezza_schermo - img_vincitore.get_width()) // 2
    posizione_y = (altezza_schermo - img_vincitore.get_height()) // 2
    
    # Visualizza l'immagine
    schermo.blit(img_vincitore, (posizione_x, posizione_y))
    pygame.display.flip()
    
    # Attendi 5 secondi
    tempo_inizio = time.time()
    while time.time() - tempo_inizio < 5:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False  # Segnala che il gioco deve terminare
        pygame.time.delay(100)  # Piccola pausa per evitare di consumare troppe risorse
    
    return True  # Continua il gioco

def inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo):
    """Inizializza i pinguini e gli altri elementi del gioco."""
    # Caricamento delle immagini
    img_rossa_1 = pygame.image.load("pinguinoRD.png")
    img_rossa_1 = pygame.transform.scale_by(img_rossa_1, dimensione_schermo/30)
    img_rossa_2 = pygame.image.load("pinguinoRF.png")
    img_rossa_2 = pygame.transform.scale_by(img_rossa_2, dimensione_schermo/30)
    img_rossa_3 = pygame.image.load("pinguinoRS.png")
    img_rossa_3 = pygame.transform.scale_by(img_rossa_3, dimensione_schermo/30)
    img_verde_1 = pygame.image.load("pinguinoVD.png")
    img_verde_1 = pygame.transform.scale_by(img_verde_1, dimensione_schermo/30)
    img_verde_2 = pygame.image.load("pinguinoVF.png")
    img_verde_2 = pygame.transform.scale_by(img_verde_2, dimensione_schermo/30)
    img_verde_3 = pygame.image.load("pinguinoVS.png")
    img_verde_3 = pygame.transform.scale_by(img_verde_3, dimensione_schermo/30)
    img_tessera = pygame.image.load("tessera.png")
    img_tessera = pygame.transform.scale_by(img_tessera, dimensione_schermo/52)
    
    # Carica modelli
    modello_su_giu_destro = joblib.load('modello_accellerazioniDx.joblib')
    modello_dx_sx_destro = joblib.load('modello_rotazioniDx.joblib')

    modello_dx_sx_mancino=joblib.load('modello_rotazioniSx.joblib')
    modello_su_giu_mancino=joblib.load('modello_accellerazioniSx.joblib')
    
    # Crea i pinguini
    pinguinoRosso = Pinguino(dimensione_schermo, img_rossa_1, img_rossa_3, schermo, modello_dx_sx_mancino, modello_su_giu_mancino, x=dimensione_schermo*4, y=dimensione_schermo*4, tipo=1)
    pinguinoVerde = Pinguino(dimensione_schermo, img_verde_1, img_verde_3, schermo, modello_dx_sx_destro, modello_su_giu_destro, x=dimensione_schermo*76, y=dimensione_schermo*56, tipo=3)
    
    # Crea la matrice di tessere
    matrice = MatriceTessere(larghezza_schermo, altezza_schermo, img_tessera, schermo)
    
    return pinguinoRosso, pinguinoVerde, matrice, img_tessera

def main():
    print("=== Inizio del gioco ===")
    pygame.init()
    dimensione_schermo = 9
    larghezza_schermo = 142 * dimensione_schermo
    altezza_schermo = 75 * dimensione_schermo


    # Impostazioni della finestra
    schermo = pygame.display.set_mode((larghezza_schermo, altezza_schermo))
    sfondo = pygame.image.load("water-drops-background.jpg").convert()
    sfondo_ridimensionato = pygame.transform.scale(sfondo, (larghezza_schermo, altezza_schermo))
    
    # Inizializza il gioco
    pinguinoRosso, pinguinoVerde, matrice, img_tessera = inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo)
    
    # Inizializza il thread di lettura dati se necessario
    ldDx = None
    ldSx = None
    if(pinguinoVerde.tipo == 3):
        ldDx = LetturaDati("COM6")  # Crea un'istanza del thread per leggere dalla micro:bit
        ldDx.start()

    if(pinguinoRosso.tipo == 4):
        ldSx = LetturaDati("COM6")  # Crea un'istanza del thread per leggere dalla micro:bit
        ldSx.start()
    
    # Loop principale che gestisce più partite
    gioco_attivo = True
    
    while gioco_attivo:
        datiMovimentoRosso = (0,0,0)
        datiMovimentoVerde = (0,0,0)
        in_esecuzione = True
        vincitore = None
        
        print("Inizia una nuova partita")
        
        # Ciclo di gioco per una singola partita
        while in_esecuzione:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    in_esecuzione = False
                    gioco_attivo = False
            
            # Pulisci lo schermo
            schermo.blit(sfondo_ridimensionato, (0, 0))
            
            # Leggi dati dal micro:bit se presente
            if(pinguinoVerde.tipo == 3 and ldDx is not None):
                dati_microbitDx = ldDx.mainLettura()
                if dati_microbitDx is not None:
                    dati_microbit_floatDx = [float(x) for x in dati_microbitDx.split(",")[:3]]
                    print(dati_microbit_floatDx, " il tipo è ", type(dati_microbit_floatDx[0]))
                    datiMovimentoVerde = dati_microbit_floatDx
                else:
                    print("dati_microbit è None")

            if(pinguinoRosso.tipo == 4 and ldSx is not None):
                dati_microbitSx = ldSx.mainLettura()
                if dati_microbitSx is not None:
                    dati_microbit_floatSx = [float(x) for x in dati_microbitSx.split(",")[:3]]
                    print(dati_microbit_floatSx, " il tipo è ", type(dati_microbit_floatSx[0]))
                    datiMovimentoRosso = dati_microbit_floatSx
                else:
                    print("dati_microbit è None")

            
            
            # Aggiorna lo stato della matrice e dei pinguini
            pinguinoRosso_caduto, pinguinoVerde_caduto = matrice.main((pinguinoRosso.x, pinguinoRosso.y), (pinguinoVerde.x, pinguinoVerde.y))
            matrice.aggiorna_stato()
            
            pinguinoRosso.main(datiMovimentoRosso)
            pinguinoVerde.main(datiMovimentoVerde)
            
            pygame.display.flip()
            
            # Raccogli dati di gioco
            dati_gioco = {
                "x_rossa": pinguinoRosso.x,
                "y_rossa": pinguinoRosso.y,
                "angolo_rossa": pinguinoRosso.angolo,
                "velocita_rossa": pinguinoRosso.velocita,
                "x_verde": pinguinoVerde.x,
                "y_verde": pinguinoVerde.y,
                "angolo_verde": pinguinoVerde.angolo,
                "velocita_verde": pinguinoVerde.velocita
            }
            
            # Verifica se un pinguino è caduto
            if pinguinoRosso_caduto:
                vincitore = 2
                in_esecuzione = False
            if pinguinoVerde_caduto:
                vincitore = 1
                in_esecuzione = False
        
        # Se c'è un vincitore, mostralo e poi ricomincia
        if vincitore and gioco_attivo:
            continua = mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo)
            if not continua:
                gioco_attivo = False
            else:
                # Reinizializza il gioco per una nuova partita
                pinguinoRosso, pinguinoVerde, matrice, img_tessera = inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo)
    
    # Chiudi il thread e pygame quando termina il gioco
    if ldDx is not None:
        ldDx.chiudi_comunicazione()
    pygame.quit()
    quit()

# Inizializzazione di Pygame
if __name__ == "__main__":  # Controlla se lo script è eseguito direttamente
    main()  # Esegue la funzione principale