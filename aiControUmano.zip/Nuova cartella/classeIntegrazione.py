import joblib
import numpy as np
import math
from stable_baselines3 import PPO

class PinguinoIAController:
    """
    Classe per controllare un pinguino con un'intelligenza artificiale addestrata.
    Sostituisce i controlli manuali nella classe Pinguino.
    """
    def __init__(self, modello_path="pinguino_ia_model"):
        """
        Inizializza il controller IA
        """
        try:
            # Carica il modello addestrato
            self.model = PPO.load(modello_path)
            print(f"Modello IA caricato con successo da {modello_path}")
            self.model_loaded = True
        except Exception as e:
            print(f"Errore nel caricamento del modello: {e}")
            self.model_loaded = False
        
        # Buffer per memorizzare gli stati recenti
        self.state_history = []
        
        # Ultima azione scelta dall'IA
        self.last_action = 0
        
        # Flag per indicare se è la prima chiamata
        self.first_call = True
    
    def prepare_observation(self, pinguino_self, pinguino_opponent, tessere_stato):
        """
        Prepara un'osservazione per il modello IA basata sullo stato attuale del gioco
        """
        # Estrai i dati rilevanti dai pinguini
        x_self = pinguino_self.x
        y_self = pinguino_self.y
        angolo_self = pinguino_self.angolo
        velocita_self = pinguino_self.velocita
        
        x_opponent = pinguino_opponent.x
        y_opponent = pinguino_opponent.y
        
        # Converti la matrice dello stato delle tessere in un array piatto
        # tessere_stato deve essere una matrice numpy o una lista di liste
        if isinstance(tessere_stato, list):
            tessere_array = np.array(tessere_stato, dtype=np.float32).flatten()
        else:
            tessere_array = tessere_stato.flatten()
        
        # Crea l'array di osservazione
        observation = np.array([
            x_self, y_self, angolo_self, velocita_self,
            x_opponent, y_opponent,
            *tessere_array  # Aggiungi tutti gli elementi della matrice appiattita
        ], dtype=np.float32)
        
        # Aggiorna la storia degli stati
        self.state_history.append(observation)
        if len(self.state_history) > 4:  # Mantieni solo gli ultimi 4 stati
            self.state_history.pop(0)
        
        return observation
    
    def get_action(self, pinguino_self, pinguino_opponent, tessere_stato):
        """
        Determina l'azione da intraprendere basata sullo stato attuale del gioco
        Restituisce un movimento simulato della micro:bit (dati_movimento)
        """
        # Se il modello non è stato caricato, restituisci un movimento casuale
        if not self.model_loaded:
            return self._get_random_movement()
        
        # Prepara l'osservazione
        observation = self.prepare_observation(pinguino_self, pinguino_opponent, tessere_stato)
        
        # Se è la prima chiamata, inizializza la storia con lo stato corrente
        if self.first_call:
            for _ in range(3):  # Aggiungi lo stato corrente 3 volte per inizializzare la storia
                self.state_history.append(observation)
            self.first_call = False
        
        # Ottieni l'azione dal modello
        try:
            action, _ = self.model.predict(observation.reshape(1, -1))
            self.last_action = action
        except Exception as e:
            print(f"Errore nella predizione dell'azione: {e}")
            action = np.random.randint(0, 6)  # Azione casuale in caso di errore
            self.last_action = action
        
        # Converti l'azione discreta in un movimento simulato
        return self._convert_action_to_movement(action)
    
    def _convert_action_to_movement(self, action):
        """
        Converte un'azione discreta in un movimento simulato per la classe Pinguino
        Restituisce un array [x, y, z] che simula i dati della micro:bit
        """
        # Questo mapping dipende da come hai implementato l'interpretazione dei dati
        # nella tua classe Pinguino. Dovrai adattarlo in base al tuo codice.
        
        # Esempio di mapping:
        # 0: nessuna azione -> [0, 0, 0]
        # 1: accelera -> [0, 100, 0]
        # 2: ruota sinistra -> [-100, 0, 0]
        # 3: ruota destra -> [100, 0, 0]
        # 4: accelera e ruota sinistra -> [-100, 100, 0]
        # 5: accelera e ruota destra -> [100, 100, 0]
        
        actions_mapping = {
            0: [0, 0, 0],     # Nessuna azione
            1: [0, 100, 0],   # Accelera
            2: [-100, 0, 0],  # Ruota sinistra
            3: [100, 0, 0],   # Ruota destra
            4: [-100, 100, 0],# Accelera e ruota sinistra
            5: [100, 100, 0]  # Accelera e ruota destra
        }
        
        # Ottieni i valori corrispondenti all'azione
        action_int = int(action)
        return actions_mapping.get(action_int, [0, 0, 0])
    
    def _get_random_movement(self):
        """
        Genera un movimento casuale nel caso in cui il modello non sia disponibile
        """
        # Genera valori casuali tra -100 e 100 per x e y
        x = np.random.randint(-100, 101)
        y = np.random.randint(-100, 101)
        z = 0  # Valore z costante (non usato)
        
        return [x, y, z]