import pygame
import pandas as pd
from pinguino import Pinguino
import joblib
from letturaDati import LetturaDati
from sklearn import *
from matriceTessere import MatriceTessere
import time
import os
from pinguino_env import PinguinoEnv
from pinguino_agent import DQNAgent

def mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo):
    """Mostra l'immagine del vincitore e attende 5 secondi."""
    if vincitore == 1:
        img_vincitore = pygame.image.load("RossoVinto.png")
    else:
        img_vincitore = pygame.image.load("VerdeVinto.png")
    
    img_vincitore = pygame.transform.scale_by(img_vincitore, dimensione_schermo/10)
    
    posizione_x = (larghezza_schermo - img_vincitore.get_width()) // 2
    posizione_y = (altezza_schermo - img_vincitore.get_height()) // 2
    
    schermo.blit(img_vincitore, (posizione_x, posizione_y))
    pygame.display.flip()
    
    tempo_inizio = time.time()
    while time.time() - tempo_inizio < 5:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False  # il gioco termina
        pygame.time.delay(100) 
    
    return True  # Continua il gioco

def inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo, is_mancino=True):
    img_rossa_1 = pygame.image.load("pinguinoRD.png")
    img_rossa_1 = pygame.transform.scale_by(img_rossa_1, dimensione_schermo/30)
    img_rossa_2 = pygame.image.load("pinguinoRF.png")
    img_rossa_2 = pygame.transform.scale_by(img_rossa_2, dimensione_schermo/30)
    img_rossa_3 = pygame.image.load("pinguinoRS.png")
    img_rossa_3 = pygame.transform.scale_by(img_rossa_3, dimensione_schermo/30)
    img_verde_1 = pygame.image.load("pinguinoVD.png")
    img_verde_1 = pygame.transform.scale_by(img_verde_1, dimensione_schermo/30)
    img_verde_2 = pygame.image.load("pinguinoVF.png")
    img_verde_2 = pygame.transform.scale_by(img_verde_2, dimensione_schermo/30)
    img_verde_3 = pygame.image.load("pinguinoVS.png")
    img_verde_3 = pygame.transform.scale_by(img_verde_3, dimensione_schermo/30)
    img_tessera = pygame.image.load("tessera.png")
    img_tessera = pygame.transform.scale_by(img_tessera, dimensione_schermo/52)
    
    # Carica modelli per mano destra
    modello_su_giu_destro = joblib.load('modello_accellerazioniDx.joblib')
    modello_dx_sx_destro = joblib.load('modello_rotazioniDx.joblib')
  
    # Carica modelli per mano sinistra
    modello_dx_sx_mancino = joblib.load('modello_rotazioniSx.joblib')
    modello_su_giu_mancino = joblib.load('modello_accellerazioniSx.joblib')
    
    # Crea i pinguini in base alla mano utilizzata dall'utente
    if is_mancino:
        # Per mancini
        pinguinoRosso = Pinguino(dimensione_schermo, img_rossa_1, img_rossa_3, schermo, 
                                modello_dx_sx_mancino, modello_su_giu_mancino, 
                                x=dimensione_schermo*4, y=dimensione_schermo*4, tipo=1)
    else:
        # Per destri
        pinguinoRosso = Pinguino(dimensione_schermo, img_rossa_1, img_rossa_3, schermo, 
                                modello_dx_sx_destro, modello_su_giu_destro, 
                                x=dimensione_schermo*4, y=dimensione_schermo*4, tipo=1)
    
    # Il pinguino verde è sempre controllato dall'IA
    pinguinoVerde = Pinguino(dimensione_schermo, img_verde_1, img_verde_3, schermo, 
                            None, None, 
                            x=dimensione_schermo*76, y=dimensione_schermo*56, tipo=5)  # Tipo 5 = IA
    
    # Crea la matrice di tessere
    matrice = MatriceTessere(larghezza_schermo, altezza_schermo, img_tessera, schermo)
    
    return pinguinoRosso, pinguinoVerde, matrice, img_tessera

def main():
    print("=== Inizio del gioco ===")
    
    train_mode = False           #True per la modalità addestramento
    model_path = "pinguino_model.h5"  # Percorso del modello 
    is_mancino = True            #True per mancino, False per destrimano
    
    pygame.init()
    dimensione_schermo = 9
    larghezza_schermo = 142 * dimensione_schermo
    altezza_schermo = 75 * dimensione_schermo

    schermo = pygame.display.set_mode((larghezza_schermo, altezza_schermo))
    pygame.display.set_caption("Pinguino Game - " + ("Mancino" if is_mancino else "Destro"))
    sfondo = pygame.image.load("water-drops-background.jpg").convert()
    sfondo_ridimensionato = pygame.transform.scale(sfondo, (larghezza_schermo, altezza_schermo))
    
    print(f"Configurazione: {'Mancino' if is_mancino else 'Destro'}")
    
    pinguinoRosso, pinguinoVerde, matrice, img_tessera = inizializza_gioco(
        dimensione_schermo, larghezza_schermo, altezza_schermo, schermo, is_mancino
    )
    
    env = PinguinoEnv(dimensione_schermo, larghezza_schermo, altezza_schermo)
    agent = DQNAgent(env)
    
    # Carica un modello pre-addestrato se esiste e non siamo in modalità addestramento
    if os.path.exists(model_path) and not train_mode:
        try:
            agent.load(model_path)
            #limitare l'esplorazione casuale
            agent.epsilon = 0.01
        except:
            print("Errore nel caricamento del modello, usando un agente nuovo")
    
    # Inizializza il thread di lettura dati solo se necessario
    ldDx = None
    if pinguinoRosso.tipo == 3:  # Se il pinguino rosso è controllato da micro:bit
        ldDx = LetturaDati()
        ldDx.start()
    
    # Contatori per statistiche di addestramento
    total_games = 0
    ai_wins = 0
    human_wins = 0
    
    gioco_attivo = True
    
    while gioco_attivo:
        datiMovimentoRosso = None
        in_esecuzione = True
        vincitore = None
        
        # Inizializza l'ambiente con lo stato corrente del gioco
        env.set_state(pinguinoRosso, pinguinoVerde, matrice, schermo)
        state = env.reset()[0]  # [0] per ottenere solo l'osservazione
        
        step_count = 0
        total_reward = 0
        
        print("Inizia una nuova partita")
        
        while in_esecuzione:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    in_esecuzione = False
                    gioco_attivo = False
            
            # Pulisci lo schermo
            schermo.blit(sfondo_ridimensionato, (0, 0))
            
            # Leggi dati dal microbit se presente per l'umano
            if pinguinoRosso.tipo == 3 and ldDx is not None:
                dati_microbitDx = ldDx.mainLettura()
                if dati_microbitDx is not None:
                    dati_microbit_floatDx = [float(x) for x in dati_microbitDx.split(",")[:3]]
                    datiMovimentoRosso = dati_microbit_floatDx
            
            # L'agente IA sceglie un'azione
            action = agent.act(state)
            
            # Esegui l'azione
            next_state, reward, terminated, truncated, info = env.step(action)
            
            # Aggiorna lo stato della matrice e dei pinguini
            pinguinoRosso_caduto, pinguinoVerde_caduto = matrice.main(
                (pinguinoRosso.x, pinguinoRosso.y), 
                (pinguinoVerde.x, pinguinoVerde.y)
            )
            matrice.aggiorna_stato()
            
            # Aggiorna il pinguino controllato dall'umano
            pinguinoRosso.main(datiMovimentoRosso)
            
            # Il pinguino IA è aggiornato nell'env.step()
            # aggiorna la visualizzazione
            pinguinoVerde.posiziona_immagine(schermo, pinguinoVerde.x, pinguinoVerde.y, pinguinoVerde.angolo)
            
            pygame.display.flip()
            
            # Memorizza l'esperienza se in modalità addestramento
            if train_mode:
                done = terminated or truncated
                agent.remember(state, action, reward, next_state, done)
                
                # Addestra l'agente
                if len(agent.memory) > 10:  # si assicura di avere abbastanza campioni
                    agent.replay(10)
            
            state = next_state
            total_reward += reward
            step_count += 1
            
            # Verifica se un pinguino è caduto
            if pinguinoRosso_caduto:
                vincitore = 2
                ai_wins += 1
                in_esecuzione = False
            if pinguinoVerde_caduto:
                vincitore = 1
                human_wins += 1
                in_esecuzione = False
        
        total_games += 1
        print(f"Partita {total_games} finita con vincitore: {'AI' if vincitore == 2 else 'Umano'}")
        print(f"Punteggio: Umano {human_wins} - AI {ai_wins}")
        print(f"Step: {step_count}, Reward totale: {total_reward:.2f}")
        
        # Se in modalità addestramento, salva periodicamente il modello
        if train_mode and total_games % 10 == 0:
            agent.save(model_path)
            print(f"Modello salvato in {model_path}")
        
        # Se c'è un vincitore, mostralo e poi ricomincia
        if vincitore and gioco_attivo:
            continua = mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo)
            if not continua:
                gioco_attivo = False
            else:
                # Reinizializza il gioco per una nuova partita
                pinguinoRosso, pinguinoVerde, matrice, img_tessera = inizializza_gioco(
                    dimensione_schermo, larghezza_schermo, altezza_schermo, schermo, is_mancino
                )
    
    # Salva il modello finale se in modalità addestramento
    if train_mode:
        agent.save(model_path)
        print(f"Modello finale salvato in {model_path}")
    
    # Chiudi il thread e pygame quando termina il gioco
    if ldDx is not None:
        ldDx.chiudi_comunicazione()
    pygame.quit()
    quit()

if __name__ == "__main__":  
    main() 