import pygame
import math
from proiettile import Proiettile
import joblib


class Navicella(pygame.sprite.Sprite) :


    # angolo=0
    # velocita=0
    # rotazione=0
    larghezza_schermo=0
    altezza_schermo=0

    def __init__(self, larghezza_schermo, altezza_schermo, immagine, schermo,modello_dx_sx, modello_su_giu, x, y, tipo, ):
        pygame.sprite.Sprite.__init__(self)
        self.larghezza_schermo=larghezza_schermo
        self.altezza_schermo=altezza_schermo
        self.image=immagine
        self.schermo=schermo
        self.modello_dx_sx=modello_dx_sx
        self.modello_su_giu=modello_su_giu
        self.x = x
        self.y = y
        self.angolo = 0 # Angolo iniziale in radianti
        self.velocita=0.3
        self.rotazione=0.4
        self.accellerazione=0.1
        self.vite=5
        self.bordo=35
        
        self.mask = pygame.mask.from_surface(immagine) 
        self.tipo=tipo
        self.rect = self.image.get_rect()  # Crea il rettangolo *dopo* aver caricato l'immagine
        self.rect.x = x  # Posizione iniziale
        self.rect.y = y
        
        
        
        if(tipo==1):
            self.colore="rossa"
        else:
            self.colore="verde"
        # self.decellerazione=0.05
        pass

    def trova_movimento_dx_sx(self, dati_movimento):
        # Caricamento del modello salvato
        # Esempio di nuovo movimento da classificare
        nuovo_movimento = dati_movimento#[-572.0,328.0,784.0]  # x, y e z
        risultato =  self.modello_dx_sx.predict([nuovo_movimento])  # si aspetta un un array con forma (n_samples, n_features)  
        print("Classe predetta:", risultato[0])
                
        return risultato[0]

    def trova_movimento_su_giu(self, dati_movimento):
        # Caricamento del modello salvato
        # Esempio di nuovo movimento da classificare
        nuovo_movimento = dati_movimento#[-572.0,328.0,784.0]  # x, y e z
        risultato =  self.modello_su_giu.predict([nuovo_movimento])  # si aspetta un un array con forma (n_samples, n_features)  
        print("Classe predetta:", risultato[0])
                
        return risultato[0]

    def posiziona_immagine(self, schermo, immagine, x, y, angolo):
        """Posiziona e ruota l'immagine al centro delle coordinate specificate."""
        immagine_ruotata = pygame.transform.rotate(immagine, math.degrees(angolo))  # Ruota l'immagine
        immagine_rect = immagine_ruotata.get_rect(center=(x, y))
        self.rect=immagine_rect
        schermo.blit(immagine_ruotata, immagine_rect)
        return immagine_ruotata


    def decellera(self, velocita):
        
            velocita -= self.accellerazione
        # Limita la velocità minima (opzionale)
            velocita = max(velocita, 2)
            return velocita


    def accellera(self, velocita):
            velocita += self.accellerazione
            velocita = min(velocita, 3) 
            return velocita
    
    def ruota_sx(self, angolo, rotazione):
        angolo = (angolo + math.radians(rotazione)) % (2 * math.pi)  # Rotazione antioraria
        return angolo
    def ruota_dx(self, angolo, rotazione):
        angolo = (angolo - math.radians(rotazione)) % (2 * math.pi)  # Rotazione oraria
        return angolo
    
    def calcola_coordinate(self, x, y, angolo, velocita):
        """Calcola le nuove coordinate in base all'angolo e alla velocità."""
        x += velocita * math.cos(angolo)
        y -= velocita * math.sin(angolo)  # Ricorda: l'asse y è invertito in Pygame
        return x, y

    def riduci_vite(self):
        self.vite=self.vite-1
        print(self.colore, " vite:", self.vite)
        if self.vite==0:
            print("navicella ", self.colore, " ha perso!")

    

    def gestisci_movimento(self, datiMovimento):
        keys = pygame.key.get_pressed()
        if self.tipo==1:
            
            
            if keys[pygame.K_w]:
                self.velocita= self.accellera(self.velocita)
            else:
                self.velocita= self.decellera(self.velocita)
            if keys[pygame.K_a]:
                self.angolo= self.ruota_sx(self.angolo, self.rotazione)
                
            if keys[pygame.K_d]:
                self.angolo= self.ruota_dx(self.angolo, self.rotazione)
            
            
        elif self.tipo==2:
            
            
            if keys[pygame.K_i]:
                self.velocita= self.accellera(self.velocita)
            else:
                self.velocita= self.decellera(self.velocita)
            if keys[pygame.K_j]:
                self.angolo= self.ruota_sx(self.angolo, self.rotazione)
                
            if keys[pygame.K_l]:
                self.angolo= self.ruota_dx(self.angolo, self.rotazione)

        elif self.tipo==3:
            movimento_dx_sx=self.trova_movimento_dx_sx(datiMovimento)
            if(movimento_dx_sx=="dx"):
                self.ruota_dx(self.angolo, self.rotazione)
            elif(movimento_dx_sx=="sx"):
                self.ruota_sx(self.angolo, self.rotazione)
            else:
                None
            movimento_su_giu=self.trova_movimento_su_giu(datiMovimento)
            if(movimento_su_giu=="av"):
                self.accellera(self.velocita)
            else:
                None
            

        self.x, self.y = self.calcola_coordinate(self.x, self.y, self.angolo, self.velocita)
        if self.x < self.bordo:
            self.x = self.bordo
        elif self.x > self.larghezza_schermo-self.bordo:
            self.x = self.larghezza_schermo-self.bordo
        if self.y < self.bordo:
            self.y = self.bordo
        elif self.y > self.altezza_schermo-self.bordo:
            self.y = self.altezza_schermo-self.bordo


    def main(self, datiMovimento):
        """Gestisce il movimento e la rotazione dell'immagine con le frecce."""
        self.posiziona_immagine(self.schermo, self.image, self.x, self.y, self.angolo)
        # self.disegna_hitbox()
        
        self.gestisci_movimento(datiMovimento)
        

    
        

        self.mask= pygame.mask.from_surface(self.image)

            
            


