import numpy as np
import random
from collections import deque
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

class DQNAgent:
    def __init__(self, env):
        # Parametri dell'ambiente
        self.env = env
        self.state_size = (7, 14, 8)  # Matrice tessere 7x14 + 8 valori (posizioni, angoli, velocità)
        self.action_size = env.action_space.n
        
        # Parametri dell'agente
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95    # fattore di sconto
        self.epsilon = 1.0   # esplorazione
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = 0.001
        self.update_target_frequency = 10
        
        # Reti neurali principali e target
        self.model = self._build_model()
        self.target_model = self._build_model()
        self.update_target_model()
        
        # Per il conteggio degli step
        self.train_step_counter = tf.Variable(0)
    
    def _build_model(self):
        """Costruisce una rete neurale per approssimare la Q-function."""
        # Input per le features dei pinguini
        input_features = layers.Input(shape=(8,))
        features_layer = layers.Dense(16, activation='relu')(input_features)
        
        # Input per la matrice delle tessere
        input_grid = layers.Input(shape=(7, 14, 1))
        conv1 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(input_grid)
        conv2 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(conv1)
        flat = layers.Flatten()(conv2)
        
        # Combinazione degli input
        combined = layers.Concatenate()([features_layer, flat])
        dense1 = layers.Dense(256, activation='relu')(combined)
        dense2 = layers.Dense(128, activation='relu')(dense1)
        output = layers.Dense(self.action_size, activation='linear')(dense2)
        
        model = keras.Model(inputs=[input_features, input_grid], outputs=output)
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=self.learning_rate),
                      loss='mse')
        return model
    
    def update_target_model(self):
        """Aggiorna il modello target con i pesi del modello principale."""
        self.target_model.set_weights(self.model.get_weights())
    
    def remember(self, state, action, reward, next_state, done):
        """Memorizza l'esperienza nel replay buffer."""
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state):
        """Sceglie un'azione basata sulla policy epsilon-greedy."""
        if np.random.rand() <= self.epsilon:
            return np.random.randint(self.action_size)
        
        # Prepara lo stato per la rete
        features, grid = self._preprocess_state(state)
        act_values = self.model.predict([features, grid], verbose=0)
        return np.argmax(act_values[0])
    
    def _preprocess_state(self, state):
        """Prepara lo stato per l'input alla rete neurale."""
        # Estrai i dati dal dizionario dello stato
        pinguino_rosso_pos = state['pinguino_rosso_pos']
        pinguino_verde_pos = state['pinguino_verde_pos']
        pinguino_rosso_angolo = state['pinguino_rosso_angolo']
        pinguino_verde_angolo = state['pinguino_verde_angolo']
        pinguino_rosso_velocita = state['pinguino_rosso_velocita']
        pinguino_verde_velocita = state['pinguino_verde_velocita']
        stato_tessere = state['stato_tessere']
        
        # Features numeriche
        features = np.concatenate([
            pinguino_rosso_pos, 
            pinguino_verde_pos,
            pinguino_rosso_angolo,
            pinguino_verde_angolo,
            pinguino_rosso_velocita,
            pinguino_verde_velocita
        ]).reshape(1, 8)
        
        # Griglia delle tessere
        grid = np.expand_dims(stato_tessere, axis=(0, -1))
        
        return features, grid
    
    def replay(self, batch_size):
        """Addestra il modello con un mini-batch di esperienze."""
        if len(self.memory) < batch_size:
            return
        
        minibatch = random.sample(self.memory, batch_size)
        
        for state, action, reward, next_state, done in minibatch:
            features, grid = self._preprocess_state(state)
            target = self.model.predict([features, grid], verbose=0)
            
            if done:
                target[0][action] = reward
            else:
                next_features, next_grid = self._preprocess_state(next_state)
                t = self.target_model.predict([next_features, next_grid], verbose=0)
                target[0][action] = reward + self.gamma * np.amax(t)
                
            self.model.fit([features, grid], target, epochs=1, verbose=0)
        
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
        
        # Aggiorna il modello target periodicamente
        if self.train_step_counter % self.update_target_frequency == 0:
            self.update_target_model()
        self.train_step_counter.assign_add(1)
    
    def load(self, name):
        """Carica i pesi del modello."""
        self.model.load_weights(name)
    
    def save(self, name):
        """Salva i pesi del modello."""
        self.model.save_weights(name)