import gymnasium as gym
import numpy as np
from gymnasium import spaces
import pygame

class PinguinoEnv(gym.Env):
    """Ambiente Gymnasium per il gioco dei pinguini."""
    metadata = {"render_modes": ["human"], "render_fps": 30}

    def __init__(self, dimensione_schermo, larghezza_schermo, altezza_schermo):
        super(PinguinoEnv, self).__init__()
        
        # Spazio delle azioni: 0 = niente, 1 = accellera, 2 = ruota sx, 3 = ruota dx
        self.action_space = spaces.Discrete(4)
        
        # Spazio di osservazione: posizione pinguino rosso (x,y), posizione pinguino verde (x,y), 
        # angoli dei pinguini, velocità, e stato tessere (matrice 7x14)
        self.observation_space = spaces.Dict({
            'pinguino_rosso_pos': spaces.Box(low=0, high=max(larghezza_schermo, altezza_schermo), shape=(2,), dtype=np.float32),
            'pinguino_verde_pos': spaces.Box(low=0, high=max(larghezza_schermo, altezza_schermo), shape=(2,), dtype=np.float32),
            'pinguino_rosso_angolo': spaces.Box(low=0, high=2*np.pi, shape=(1,), dtype=np.float32),
            'pinguino_verde_angolo': spaces.Box(low=0, high=2*np.pi, shape=(1,), dtype=np.float32),
            'pinguino_rosso_velocita': spaces.Box(low=0, high=dimensione_schermo*1, shape=(1,), dtype=np.float32),
            'pinguino_verde_velocita': spaces.Box(low=0, high=dimensione_schermo*1, shape=(1,), dtype=np.float32),
            'stato_tessere': spaces.Box(low=0, high=1, shape=(7, 14), dtype=np.int8)
        })
        
        self.dimensione_schermo = dimensione_schermo
        self.larghezza_schermo = larghezza_schermo
        self.altezza_schermo = altezza_schermo
        
        # Stato interno
        self.pinguino_rosso = None
        self.pinguino_verde = None
        self.matrice_tessere = None
        self.schermo = None
        
        # Cronometraggio per evitare azioni troppo frequenti
        self.last_action_time = 0
        self.action_delay = 50  # millisecondi
        
    def reset(self, seed=None, options=None):
        """Resetta l'ambiente al suo stato iniziale."""
        super().reset(seed=seed)
        
        # Qui dovremmo reinizializzare il gioco
        # Ma poiché il tuo gioco ha già funzioni di inizializzazione,
        # useremo quelle esistenti quando integriamo l'ambiente
        
        # Ritorniamo un'osservazione vuota temporanea
        observation = self._get_observation()
        info = {}
        
        return observation, info
    
    def step(self, action):
        """Esegui un'azione nell'ambiente."""
        # Limita la frequenza delle azioni
        current_time = pygame.time.get_ticks()
        if current_time - self.last_action_time < self.action_delay:
            return self._get_observation(), 0.0, False, False, {}
        
        self.last_action_time = current_time
        
        # Traduci azione per il pinguino verde (AI)
        # 0 = niente, 1 = accellera, 2 = ruota sx, 3 = ruota dx
        if action == 1:  # Accelera
            self.pinguino_verde.velocita = self.pinguino_verde.accellera(self.pinguino_verde.velocita)
        elif action == 2:  # Ruota a sinistra
            self.pinguino_verde.angolo = self.pinguino_verde.ruota_sx(self.pinguino_verde.angolo, self.pinguino_verde.rotazione)
        elif action == 3:  # Ruota a destra
            self.pinguino_verde.angolo = self.pinguino_verde.ruota_dx(self.pinguino_verde.angolo, self.pinguino_verde.rotazione)
        else:
            self.pinguino_verde.velocita = self.pinguino_verde.decellera(self.pinguino_verde.velocita)
            
        # Calcola le nuove coordinate
        self.pinguino_verde.x, self.pinguino_verde.y = self.pinguino_verde.calcola_coordinate(
            self.pinguino_verde.x, self.pinguino_verde.y, 
            self.pinguino_verde.angolo, self.pinguino_verde.velocita
        )
              
        # Controlla se i pinguini sono caduti
        try:
            pinguino_rosso_caduto, pinguino_verde_caduto = self.matrice_tessere.main(
                (self.pinguino_rosso.x, self.pinguino_rosso.y), 
                (self.pinguino_verde.x, self.pinguino_verde.y)
            )
        except:
            pinguino_rosso_caduto, pinguino_verde_caduto = False, False
        
        # Calcola la ricompensa
        reward = self._calculate_reward(pinguino_rosso_caduto, pinguino_verde_caduto)
        
        # Verifica se il gioco è terminato
        terminated = pinguino_rosso_caduto or pinguino_verde_caduto
        truncated = False  # Non impostiamo limiti di tempo per ora
        
        # Ottieni l'osservazione aggiornata
        observation = self._get_observation()
        
        # Informazioni aggiuntive
        info = {
            'pinguino_rosso_caduto': pinguino_rosso_caduto,
            'pinguino_verde_caduto': pinguino_verde_caduto
        }
        
        return observation, reward, terminated, truncated, info
    
    def _calculate_reward(self, pinguino_rosso_caduto, pinguino_verde_caduto):
        # Penalità per cadere
        if pinguino_verde_caduto:
            return -10.0
        
        # Ricompensa per far cadere l'avversario
        if pinguino_rosso_caduto:
            return 10.0
        
        # Piccola ricompensa per sopravvivere
        return 0.01
    
    def _get_observation(self):
        """Ottieni lo stato corrente come osservazione."""
        if self.pinguino_rosso is None or self.pinguino_verde is None or self.matrice_tessere is None:
            # Restituisci un'osservazione vuota se l'ambiente non è inizializzato
            return {
                'pinguino_rosso_pos': np.zeros(2, dtype=np.float32),
                'pinguino_verde_pos': np.zeros(2, dtype=np.float32),
                'pinguino_rosso_angolo': np.zeros(1, dtype=np.float32),
                'pinguino_verde_angolo': np.zeros(1, dtype=np.float32),
                'pinguino_rosso_velocita': np.zeros(1, dtype=np.float32),
                'pinguino_verde_velocita': np.zeros(1, dtype=np.float32),
                'stato_tessere': np.ones((7, 14), dtype=np.int8)
            }
        
        # Estrai lo stato delle tessere dalla matrice
        stato_tessere = np.ones((7, 14), dtype=np.int8)
        for i in range(self.matrice_tessere.righe):
            for j in range(self.matrice_tessere.colonne):
                stato_tessere[i, j] = 1 if self.matrice_tessere.stato_tessere[i][j] else 0
        
        return {
            'pinguino_rosso_pos': np.array([self.pinguino_rosso.x, self.pinguino_rosso.y], dtype=np.float32),
            'pinguino_verde_pos': np.array([self.pinguino_verde.x, self.pinguino_verde.y], dtype=np.float32),
            'pinguino_rosso_angolo': np.array([self.pinguino_rosso.angolo], dtype=np.float32),
            'pinguino_verde_angolo': np.array([self.pinguino_verde.angolo], dtype=np.float32),
            'pinguino_rosso_velocita': np.array([self.pinguino_rosso.velocita], dtype=np.float32),
            'pinguino_verde_velocita': np.array([self.pinguino_verde.velocita], dtype=np.float32),
            'stato_tessere': stato_tessere
        }
    
    def set_state(self, pinguino_rosso, pinguino_verde, matrice_tessere, schermo): #inizializza stato delle variabii di gioco
        self.pinguino_rosso = pinguino_rosso
        self.pinguino_verde = pinguino_verde
        self.matrice_tessere = matrice_tessere
        self.schermo = schermo
    
    def render(self):
        """Rendering dell'ambiente."""
        # Non abbiamo bisogno di fare nulla qui poiché il rendering è gestito dal gioco
        pass
    
    def close(self):
        """Pulisci le risorse."""
        pass