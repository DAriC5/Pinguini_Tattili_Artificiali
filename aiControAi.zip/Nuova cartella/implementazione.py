import gymnasium as gym
import numpy as np
from gymnasium import spaces
import pygame
import math
from collections import deque

# Definizione dell'ambiente Gymnasium per il gioco dei pinguini
class PinguinoEnv(gym.Env):
    """Ambiente personalizzato che segue l'interfaccia di Gymnasium."""
    metadata = {'render_modes': ['human'], 'render_fps': 30}
    
    def __init__(self, dimensione_schermo=9, render_mode=None):
        super(PinguinoEnv, self).__init__()
        
        # Parametri dell'ambiente
        self.dimensione_schermo = dimensione_schermo
        self.larghezza_schermo = 142 * dimensione_schermo
        self.altezza_schermo = 75 * dimensione_schermo
        self.render_mode = render_mode
        
        # Definizione dello spazio delle azioni
        # 0: nessuna azione, 1: accelera, 2: ruota sinistra, 3: ruota destra, 4: accelera e ruota sinistra, 5: accelera e ruota destra
        self.action_space = spaces.Discrete(6)
        
        # Definizione dello spazio delle osservazioni
        # [x_pinguino, y_pinguino, angolo_pinguino, velocita_pinguino, x_avversario, y_avversario, stato_tessere (flattened)]
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, 0, 0, 0] + [0] * (7 * 14)),  # 7x14 è la dimensione della matrice di tessere
            high=np.array([self.larghezza_schermo, self.altezza_schermo, 2*math.pi, self.dimensione_schermo*2, 
                           self.larghezza_schermo, self.altezza_schermo] + [1] * (7 * 14)),
            dtype=np.float32
        )
        
        # Inizializza le componenti del gioco
        if render_mode == 'human':
            pygame.init()
            self.screen = pygame.display.set_mode((self.larghezza_schermo, self.altezza_schermo))
            pygame.display.set_caption("Pinguino IA")
            self.clock = pygame.time.Clock()
        
        # Storia degli stati recenti (per gestire informazioni temporali)
        self.state_history = deque(maxlen=4)  # Mantiene gli ultimi 4 stati
        
        # Variabili del gioco
        self.reset()
    
    def reset(self, seed=None, options=None):
        """Resetta l'ambiente allo stato iniziale e restituisce l'osservazione iniziale."""
        super().reset(seed=seed)
        
        # Questo è un segnaposto - dovrà essere integrato con il tuo codice esistente
        # per inizializzare correttamente pinguini, tessere, ecc.
        
        # Inizializzazione dei pinguini
        self.pinguino_ia_x = self.dimensione_schermo * 4
        self.pinguino_ia_y = self.dimensione_schermo * 4
        self.pinguino_ia_angolo = 0
        self.pinguino_ia_velocita = self.dimensione_schermo / 25
        
        self.pinguino_avversario_x = self.dimensione_schermo * 76
        self.pinguino_avversario_y = self.dimensione_schermo * 56
        self.pinguino_avversario_angolo = 3.15
        self.pinguino_avversario_velocita = self.dimensione_schermo / 25
        
        # Inizializzazione della matrice di tessere (tutte a galla inizialmente)
        self.stato_tessere = np.ones((7, 14), dtype=np.float32)
        
        # Resetta la storia degli stati
        self.state_history.clear()
        observation = self._get_observation()
        
        # Aggiungi lo stato iniziale alla storia
        for _ in range(4):
            self.state_history.append(observation)
        
        info = {}
        return observation, info
    
    def _get_observation(self):
        """Costruisce l'osservazione dallo stato corrente del gioco."""
        # Unisci tutte le informazioni rilevanti in un array
        obs = np.array([
            self.pinguino_ia_x, 
            self.pinguino_ia_y, 
            self.pinguino_ia_angolo, 
            self.pinguino_ia_velocita,
            self.pinguino_avversario_x, 
            self.pinguino_avversario_y
        ] + self.stato_tessere.flatten().tolist(), dtype=np.float32)
        
        return obs
    
    def step(self, action):
        """Esegue un passo dell'ambiente con l'azione data."""
        # Esegui l'azione dell'IA
        self._apply_action(action)
        
        # Aggiorna la posizione del pinguino avversario (controllato dal giocatore o da un'altra logica)
        self._update_opponent()
        
        # Aggiorna lo stato delle tessere
        self._update_tiles()
        
        # Verifica se il gioco è terminato
        terminated = self._check_termination()
        truncated = False  # Per semplicità, non stiamo implementando un limite di tempo
        
        # Calcola la ricompensa
        reward = self._calculate_reward(terminated)
        
        # Ottieni la nuova osservazione
        observation = self._get_observation()
        
        # Aggiorna la storia degli stati
        self.state_history.append(observation)
        
        # Info aggiuntive (opzionale)
        info = {}
        
        if self.render_mode == 'human':
            self.render()
        
        return observation, reward, terminated, truncated, info
    
    def _apply_action(self, action):
        """Applica l'azione selezionata al pinguino IA."""
        accellerazione = self.dimensione_schermo / 100
        rotazione = self.dimensione_schermo / 1
        
        # Applica l'azione in base al valore
        if action in [1, 4, 5]:  # Azioni che includono accelerazione
            self.pinguino_ia_velocita += accellerazione
            self.pinguino_ia_velocita = min(self.pinguino_ia_velocita, self.dimensione_schermo * 1)
        else:
            self.pinguino_ia_velocita -= accellerazione
            self.pinguino_ia_velocita = max(self.pinguino_ia_velocita, self.dimensione_schermo * 0.5)
        
        if action in [2, 4]:  # Ruota a sinistra
            self.pinguino_ia_angolo = (self.pinguino_ia_angolo + math.radians(rotazione)) % (2 * math.pi)
        elif action in [3, 5]:  # Ruota a destra
            self.pinguino_ia_angolo = (self.pinguino_ia_angolo - math.radians(rotazione)) % (2 * math.pi)
        
        # Aggiorna la posizione del pinguino IA
        self.pinguino_ia_x += self.pinguino_ia_velocita * math.cos(self.pinguino_ia_angolo)
        self.pinguino_ia_y -= self.pinguino_ia_velocita * math.sin(self.pinguino_ia_angolo)
    
    def _update_opponent(self):
        """Aggiorna la posizione del pinguino avversario."""
        # In un gioco reale, questo sarebbe controllato dal giocatore umano o da un'altra logica
        # Per ora, implementiamo un movimento semplice
        
        # Esempio: l'avversario si muove verso il centro del campo
        centro_x = self.larghezza_schermo / 2
        centro_y = self.altezza_schermo / 2
        
        # Calcola la direzione verso il centro
        dx = centro_x - self.pinguino_avversario_x
        dy = centro_y - self.pinguino_avversario_y
        angolo_target = math.atan2(-dy, dx)  # Nota il -dy per l'inversione dell'asse y in Pygame
        
        # Ruota gradualmente verso l'angolo target
        diff_angolo = (angolo_target - self.pinguino_avversario_angolo + math.pi) % (2 * math.pi) - math.pi
        if abs(diff_angolo) > 0.1:
            if diff_angolo > 0:
                self.pinguino_avversario_angolo = (self.pinguino_avversario_angolo + math.radians(self.dimensione_schermo / 1)) % (2 * math.pi)
            else:
                self.pinguino_avversario_angolo = (self.pinguino_avversario_angolo - math.radians(self.dimensione_schermo / 1)) % (2 * math.pi)
        
        # Aggiorna la velocità e la posizione
        self.pinguino_avversario_velocita = self.dimensione_schermo / 25
        self.pinguino_avversario_x += self.pinguino_avversario_velocita * math.cos(self.pinguino_avversario_angolo)
        self.pinguino_avversario_y -= self.pinguino_avversario_velocita * math.sin(self.pinguino_avversario_angolo)
    
    def _update_tiles(self):
        """Aggiorna lo stato delle tessere in base alla posizione dei pinguini."""
        # Converti posizioni in indici della matrice
        riga_ia, col_ia = self._get_tile_indices(self.pinguino_ia_x, self.pinguino_ia_y)
        riga_avv, col_avv = self._get_tile_indices(self.pinguino_avversario_x, self.pinguino_avversario_y)
        
        # Segna le tessere calpestate come affondate (0)
        if 0 <= riga_ia < 7 and 0 <= col_ia < 14:
            self.stato_tessere[riga_ia, col_ia] = 0
        
        if 0 <= riga_avv < 7 and 0 <= col_avv < 14:
            self.stato_tessere[riga_avv, col_avv] = 0
        
        # Simulazione: le tessere risalgono dopo un certo tempo
        # Questo è semplificato - nella tua implementazione, dovresti usare il sistema di tempistica che hai già
        self.stato_tessere = np.minimum(self.stato_tessere + 0.01, 1.0)
    
    def _get_tile_indices(self, x, y):
        """Converte coordinate in indici della matrice di tessere."""
        tile_width = self.larghezza_schermo / 14
        tile_height = self.altezza_schermo / 7
        
        col = int(x // tile_width)
        riga = int(y // tile_height)
        
        return riga, col
    
    def _check_termination(self):
        """Verifica se il gioco è terminato."""
        bordo = -20
        
        # Controlla se il pinguino IA è caduto
        riga_ia, col_ia = self._get_tile_indices(self.pinguino_ia_x, self.pinguino_ia_y)
        
        # Fuori dai bordi dello schermo
        if (self.pinguino_ia_x < bordo or 
            self.pinguino_ia_x > self.larghezza_schermo - bordo or 
            self.pinguino_ia_y < bordo or 
            self.pinguino_ia_y > self.altezza_schermo - bordo):
            return True
        
        # Su una tessera affondata
        if 0 <= riga_ia < 7 and 0 <= col_ia < 14:
            if self.stato_tessere[riga_ia, col_ia] < 0.2:  # Tessera quasi completamente affondata
                return True
        
        return False
    
    def _calculate_reward(self, terminated):
        """Calcola la ricompensa per lo stato corrente."""
        reward = 0
        
        # Penalità per la terminazione (pinguino caduto)
        if terminated:
            reward -= 100
            return reward
        
        # Ricompensa per sopravvivere
        reward += 1
        
        # Ricompensa basata sulla distanza dal centro
        centro_x, centro_y = self.larghezza_schermo / 2, self.altezza_schermo / 2
        distanza_dal_centro = math.sqrt((self.pinguino_ia_x - centro_x)**2 + (self.pinguino_ia_y - centro_y)**2)
        distanza_normalizzata = distanza_dal_centro / (math.sqrt(centro_x**2 + centro_y**2))
        reward += 5 * (1 - distanza_normalizzata)  # Più vicino al centro = ricompensa maggiore
        
        # Ricompensa per avere tessere solide sotto di sé
        riga_ia, col_ia = self._get_tile_indices(self.pinguino_ia_x, self.pinguino_ia_y)
        if 0 <= riga_ia < 7 and 0 <= col_ia < 14:
            solid_ground = self.stato_tessere[riga_ia, col_ia]
            reward += 2 * solid_ground  # Tessera più solida = ricompensa maggiore
        
        # Ricompensa strategica: premia comportamenti che fanno cadere l'avversario
        # Calcola quante tessere sono affondate tra l'IA e l'avversario
        riga_avv, col_avv = self._get_tile_indices(self.pinguino_avversario_x, self.pinguino_avversario_y)
        if 0 <= riga_avv < 7 and 0 <= col_avv < 14 and 0 <= riga_ia < 7 and 0 <= col_ia < 14:
            # Calcola tessere affondate nel percorso tra i due pinguini
            path_tiles = self._get_tiles_in_path(riga_ia, col_ia, riga_avv, col_avv)
            sunken_tiles = sum(1 for r, c in path_tiles if self.stato_tessere[r, c] < 0.5)
            if len(path_tiles) > 0:
                sunken_ratio = sunken_tiles / len(path_tiles)
                reward += 3 * sunken_ratio  # Più tessere affondate nel percorso = più difficile per l'avversario
        
        return reward
    
    def _get_tiles_in_path(self, r1, c1, r2, c2):
        """Restituisce le coordinate delle tessere in un percorso approssimativo tra due punti."""
        path = []
        # Implementazione semplificata di Bresenham
        dx = abs(c2 - c1)
        dy = abs(r2 - r1)
        sx = 1 if c1 < c2 else -1
        sy = 1 if r1 < r2 else -1
        err = dx - dy
        
        r, c = r1, c1
        while not (r == r2 and c == c2) and len(path) < 20:  # Limite per evitare loop infiniti
            if 0 <= r < 7 and 0 <= c < 14:
                path.append((r, c))
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                c += sx
            if e2 < dx:
                err += dx
                r += sy
        
        return path
    
    def render(self):
        """Renderizza lo stato corrente dell'ambiente."""
        if self.render_mode != 'human':
            return
        
        # Pulisci lo schermo
        self.screen.fill((0, 0, 0))
        
        # Disegna le tessere
        tile_width = self.larghezza_schermo / 14
        tile_height = self.altezza_schermo / 7
        for r in range(7):
            for c in range(14):
                alpha = int(self.stato_tessere[r, c] * 255)
                color = (50, 150, 200, alpha)  # Blu con opacità variabile
                rect = pygame.Rect(c * tile_width, r * tile_height, tile_width, tile_height)
                s = pygame.Surface((tile_width, tile_height))
                s.set_alpha(alpha)
                s.fill(color)
                self.screen.blit(s, rect)
                pygame.draw.rect(self.screen, (0, 0, 0), rect, 1)  # Bordo nero
        
        # Disegna il pinguino IA
        pygame.draw.circle(self.screen, (255, 0, 0), (int(self.pinguino_ia_x), int(self.pinguino_ia_y)), 15)
        # Linea per indicare la direzione
        end_x = self.pinguino_ia_x + 30 * math.cos(self.pinguino_ia_angolo)
        end_y = self.pinguino_ia_y - 30 * math.sin(self.pinguino_ia_angolo)
        pygame.draw.line(self.screen, (255, 255, 255), 
                         (int(self.pinguino_ia_x), int(self.pinguino_ia_y)), 
                         (int(end_x), int(end_y)), 2)
        
        # Disegna il pinguino avversario
        pygame.draw.circle(self.screen, (0, 255, 0), 
                          (int(self.pinguino_avversario_x), int(self.pinguino_avversario_y)), 15)
        
        pygame.display.flip()
        self.clock.tick(self.metadata["render_fps"])
    
    def close(self):
        """Chiude l'ambiente."""
        if hasattr(self, 'screen') and self.screen is not None:
            pygame.quit()


# Integrazione con Stable Baselines 3 per l'addestramento dell'IA
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.evaluation import evaluate_policy

def train_agent(total_timesteps=50000, save_path="pinguino_ia_model"):
    """Addestra un agente PPO sull'ambiente del pinguino."""
    # Crea l'ambiente
    env = PinguinoEnv(dimensione_schermo=9)
    env = DummyVecEnv([lambda: env])
    
    # Crea e addestra l'agente
    model = PPO("MlpPolicy", env, verbose=1, learning_rate=0.0003, 
                n_steps=2048, batch_size=64, n_epochs=10, 
                gamma=0.99, gae_lambda=0.95, clip_range=0.2)
    
    model.learn(total_timesteps=total_timesteps)
    model.save(save_path)
    
    print(f"Addestramento completato e modello salvato in {save_path}")
    return model

def evaluate_agent(model_path="pinguino_ia_model", n_eval_episodes=10):
    """Valuta le prestazioni di un agente addestrato."""
    env = PinguinoEnv(dimensione_schermo=9, render_mode="human")
    model = PPO.load(model_path)
    
    mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=n_eval_episodes)
    print(f"Media ricompense: {mean_reward:.2f} +/- {std_reward:.2f}")

# Classe per integrare l'agente addestrato nel gioco originale
class IAController:
    def __init__(self, model_path="pinguino_ia_model"):
        """Inizializza il controller IA caricando il modello addestrato."""
        try:
            self.model = PPO.load(model_path)
            print(f"Modello IA caricato con successo da {model_path}")
        except Exception as e:
            print(f"Errore nel caricamento del modello: {e}")
            self.model = None
    
    def get_action(self, state):
        """Ottiene l'azione dall'IA basata sullo stato corrente del gioco."""
        if self.model is None:
            # Comportamento di fallback: azione casuale
            return np.random.randint(0, 6)
        
        # Trasforma lo stato nel formato corretto per il modello
        state_array = np.array(state, dtype=np.float32).reshape(1, -1)
        
        # Ottieni l'azione dal modello
        action, _ = self.model.predict(state_array)
        return action

# Funzione per integrare l'IA nel gioco originale
def integrate_ai_into_game():
    """Funzione principale per integrare l'IA nel gioco originale."""
    # Prima addestra un modello (questo può essere fatto una volta e poi riutilizzato)
    # train_agent(total_timesteps=50000, save_path="pinguino_ia_model")
    
    # Crea un controller IA che usa il modello addestrato
    ia_controller = IAController(model_path="pinguino_ia_model")
    
    # Questo è un segnaposto - dovrai modificare il tuo codice del gioco
    # per usare ia_controller.get_action() invece dei controlli umani per uno dei pinguini
    
    print("Controller IA pronto per l'integrazione nel gioco originale")
    return ia_controller