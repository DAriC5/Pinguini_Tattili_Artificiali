import pygame
from pinguino import Pinguino
from sklearn import *
from matriceTessere import MatriceTessere
import time
import os
from pinguino_env import PinguinoEnv
from pinguino_agent import DQNAgent

def mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo):
    if vincitore == 1:
        img_vincitore = pygame.image.load("RossoVinto.png")
    else:
        img_vincitore = pygame.image.load("VerdeVinto.png")
    
    # Ridimensiona l'immagine 
    img_vincitore = pygame.transform.scale_by(img_vincitore, dimensione_schermo/10)
    
    # Posiziona l'immagine al centro dello schermo
    posizione_x = (larghezza_schermo - img_vincitore.get_width()) // 2
    posizione_y = (altezza_schermo - img_vincitore.get_height()) // 2
    
    # Visualizza l'immagine
    schermo.blit(img_vincitore, (posizione_x, posizione_y))
    pygame.display.flip()
    
    # Attendi 5 secondi
    tempo_inizio = time.time()
    while time.time() - tempo_inizio < 5:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False  # Segnala che il gioco deve terminare
        pygame.time.delay(100)  # Piccola pausa per evitare di consumare troppe risorse
    
    return True  # Continua il gioco

def inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo, is_mancino=True):
    img_rossa_1 = pygame.image.load("pinguinoRD.png")
    img_rossa_1 = pygame.transform.scale_by(img_rossa_1, dimensione_schermo/30)
    img_rossa_2 = pygame.image.load("pinguinoRF.png")
    img_rossa_2 = pygame.transform.scale_by(img_rossa_2, dimensione_schermo/30)
    img_rossa_3 = pygame.image.load("pinguinoRS.png")
    img_rossa_3 = pygame.transform.scale_by(img_rossa_3, dimensione_schermo/30)
    img_verde_1 = pygame.image.load("pinguinoVD.png")
    img_verde_1 = pygame.transform.scale_by(img_verde_1, dimensione_schermo/30)
    img_verde_2 = pygame.image.load("pinguinoVF.png")
    img_verde_2 = pygame.transform.scale_by(img_verde_2, dimensione_schermo/30)
    img_verde_3 = pygame.image.load("pinguinoVS.png")
    img_verde_3 = pygame.transform.scale_by(img_verde_3, dimensione_schermo/30)
    img_tessera = pygame.image.load("tessera.png")
    img_tessera = pygame.transform.scale_by(img_tessera, dimensione_schermo/52)
    
    pinguinoRosso = Pinguino(dimensione_schermo, img_rossa_1, img_rossa_3, schermo, 
                            None, None, 
                            x=dimensione_schermo*32, y=dimensione_schermo*56, tipo=5)
    
    pinguinoVerde = Pinguino(dimensione_schermo, img_verde_1, img_verde_3, schermo, 
                            None, None, 
                            x=dimensione_schermo*76, y=dimensione_schermo*56, tipo=5)  # Tipo 5 = IA
    
    matrice = MatriceTessere(larghezza_schermo, altezza_schermo, img_tessera, schermo)
    
    return pinguinoRosso, pinguinoVerde, matrice

def main():
    print("=== Inizio del gioco ===")
    
    train_mode = False           # Imposta a True per la modalità addestramento
    model_path = "modello0.weights.h5"  # Percorso del modello da caricare/salvare

    train_mode2 = True           # Imposta a True per la modalità addestramento
    model_path2 = "modello1.weights.h5"  # Percorso del modello da caricare/salvare
    
    pygame.init()
    dimensione_schermo = 9
    larghezza_schermo = 142 * dimensione_schermo
    altezza_schermo = 75 * dimensione_schermo

    # Impostazioni della finestra
    schermo = pygame.display.set_mode((larghezza_schermo, altezza_schermo))
    sfondo = pygame.image.load("water-drops-background.jpg").convert()
    sfondo_ridimensionato = pygame.transform.scale(sfondo, (larghezza_schermo, altezza_schermo))

    pinguinoRosso, pinguinoVerde, matrice = inizializza_gioco(dimensione_schermo, larghezza_schermo, altezza_schermo, schermo)

    # Inizializza l'ambiente e l'agente
    env = PinguinoEnv(dimensione_schermo, larghezza_schermo, altezza_schermo)
    agent = DQNAgent(env)

    env2 = PinguinoEnv(dimensione_schermo, larghezza_schermo, altezza_schermo)
    agent2 = DQNAgent(env2)

    
    # Carica un modello pre-addestrato se esiste e non siamo in modalità addestramento
    if os.path.exists(model_path2) and not train_mode2:
        try:
            agent2.load(model_path2)
            agent2.epsilon = 0.01
        except:
            print("Errore nel caricamento del modello, usando un agente nuovo")

    if os.path.exists(model_path) and not train_mode:
        try:
            agent.load(model_path)
            agent.epsilon = 0.01
        except:
            print("Errore nel caricamento del modello, usando un agente nuovo")
    
    total_games = 0
    ai_wins = 0
    human_wins = 0
    
    gioco_attivo = True
    
    while gioco_attivo:
        in_esecuzione = True
        vincitore = None
        
        # Inizializza l'ambiente con lo stato corrente
        env.set_state(pinguinoRosso, pinguinoVerde, matrice, schermo)
        state = env.reset()[0]  # [0] per ottenere solo l'osservazione

        env2.set_state(pinguinoRosso, pinguinoVerde, matrice, schermo)
        state2 = env2.reset()[0]  # [0] per ottenere solo l'osservazione
        
        step_count = 0
        total_reward = 0

        step_count2 = 0
        total_reward2 = 0
        
        print("Inizia una nuova partita")
        
        # Ciclo di gioco per una singola partita
        while in_esecuzione:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    in_esecuzione = False
                    gioco_attivo = False
            
            # Pulisci lo schermo
            schermo.blit(sfondo_ridimensionato, (0, 0))
            
            # L'agente IA sceglie un'azione
            action = agent.act(state)
            action2 = agent2.act(state2)
            
            # Esegui l'azione nell'ambiente
            next_state, reward, terminated, truncated, info = env.step(action)
            next_state2, reward2, terminated2, truncated2, info2 = env2.step(action2)

            # Aggiorna lo stato della matrice e dei pinguini
            pinguinoRosso_caduto, pinguinoVerde_caduto = matrice.main(
                (pinguinoRosso.x, pinguinoRosso.y), 
                (pinguinoVerde.x, pinguinoVerde.y)
            )
            matrice.aggiorna_stato()
            
            # Il pinguino IA è aggiornato direttamente nell'env.step()
            # aggiornarna la visualizzazione
            pinguinoVerde.posiziona_immagine(schermo, pinguinoVerde.x, pinguinoVerde.y, pinguinoVerde.angolo)
            pinguinoRosso.posiziona_immagine(schermo, pinguinoRosso.x, pinguinoRosso.y, pinguinoRosso.angolo)
            
            pygame.display.flip()
            
            # Memorizza l'esperienza se in modalità addestramento
            if train_mode:
                done = terminated or truncated
                agent.remember(state, action, reward, next_state, done)
                
                # Addestra l'agente
                if len(agent.memory) > 32:  # Assicurati di avere abbastanza campioni
                    agent.replay(32)

            if train_mode2:
                done2 = terminated2 or truncated2
                agent2.remember(state2, action2, reward2, next_state2, done2)
                
                # Addestra l'agente
                if len(agent2.memory) > 32:  # Assicurati di avere abbastanza campioni
                    agent2.replay(32)
            
            state = next_state
            total_reward += reward
            step_count += 1
            state2 = next_state2
            total_reward2 += reward2
            step_count2 += 1
            
            # Verifica se un pinguino è caduto
            if pinguinoRosso_caduto:
                vincitore = 2
                ai_wins += 1
                in_esecuzione = False
            if pinguinoVerde_caduto:
                vincitore = 1
                human_wins += 1
                in_esecuzione = False
        
        total_games += 1
        print(f"Partita {total_games} finita con vincitore: {'AI' if vincitore == 2 else 'Umano'}")
        print(f"Punteggio: Umano {human_wins} - AI {ai_wins}")
        print(f"Step: {step_count}, Reward totale: {total_reward:.2f}")
        print(f"Step: {step_count2}, Reward totale: {total_reward2:.2f}")
        
        # Se in modalità addestramento, salva periodicamente il modello
        if train_mode and total_games % 10 == 0:
            agent.save(model_path)
            print(f"Modello salvato in {model_path}")

        if train_mode2 and total_games % 10 == 0:
            agent2.save(model_path2)
            print(f"Modello salvato in {model_path2}")
        
        # Se c'è un vincitore, mostralo e poi ricomincia
        if vincitore and gioco_attivo:
            continua = mostra_vincitore(schermo, vincitore, larghezza_schermo, altezza_schermo, dimensione_schermo)
            if not continua:
                gioco_attivo = False
            else:
                # Reinizializza il gioco per una nuova partita
                pinguinoRosso, pinguinoVerde, matrice = inizializza_gioco(
                    dimensione_schermo, larghezza_schermo, altezza_schermo, schermo
                )
    
    # Salva il modello finale se in modalità addestramento
    if train_mode:
        agent.save(model_path)
        print(f"Modello finale salvato in {model_path}")

    if train_mode2:
        agent2.save(model_path2)
        print(f"Modello finale salvato in {model_path2}")
    
    pygame.quit()
    quit()

if __name__ == "__main__":  
    main()  