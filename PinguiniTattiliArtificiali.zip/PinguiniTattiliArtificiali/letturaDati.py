import serial
import threading
import time

#gestione degli errori fatta da chat

class ThreadLetturaDati(threading.Thread):
    def __init__(self, porta_seriale, baudrate=115200, timeout=1): #baudrate = tempo di trasmissione
        threading.Thread.__init__(self)  
        self.porta_seriale = porta_seriale
        self.baudrate = baudrate
        self.timeout = timeout
        self.seriale = None #futuro oggetto che rappresenta la porta
        self.running = False
        self.data_lock = threading.Lock()
        self.ultimo_dato = None
        self.connetti()
    
    def connetti(self):
        try:
            self.seriale = serial.Serial(
                port=self.porta_seriale,
                baudrate=self.baudrate,
                timeout=self.timeout
            )
            print(f"Connessione stabilita su {self.porta_seriale}")
            return True
        except serial.SerialException as e:
            print(f"Impossibile aprire la porta {self.porta_seriale}: {e}")
            return False

    def run(self):
        self.running = True
        while self.running:
            if not self.seriale or not self.seriale.is_open:
                print("La porta seriale non è aperta. Tentativo di riconnessione...")
                if not self.connetti():
                    time.sleep(1)  
                    continue
            try:
                if self.seriale.in_waiting > 0:  # Verifica se ci sono dati disponibili nella coda
                    data = self.seriale.readline().decode().strip() #strip() rimuove gli spazi bianchi all'inizio e alla fine
                    with self.data_lock:
                        self.ultimo_dato = data
                time.sleep(0.01)  
            except serial.SerialException as e:
                print(f"Errore di comunicazione seriale: {e}")
                self.seriale.close()  
                self.seriale = None
                time.sleep(1)  
            except Exception as e:
                print(f"Errore durante la lettura: {e}")
                time.sleep(0.5)  
    
    def mainLettura(self):
        with self.data_lock:
            return self.ultimo_dato
    
    def chiudi_comunicazione(self):
        self.running = False
        if self.seriale and self.seriale.is_open:
            self.seriale.close()
            print(f"Connessione su {self.porta_seriale} chiusa.")
        self.join(timeout=1)  