import pygame
from tessera import Tessera

class MatriceTessere:
    def __init__(self, larghezza_schermo, altezza_schermo, immagine, schermo):
        self.larghezza_schermo = larghezza_schermo
        self.altezza_schermo = altezza_schermo
        self.schermo = schermo
        self.immagine = immagine
        
        print(f"Inizializzazione MatriceTessere con schermo {larghezza_schermo}x{altezza_schermo}")
        
        # Verifica che l'immagine sia valida
        if immagine is None:
            print("ERRORE: Immagine delle tessere è None!")
        
        # Dimensioni della griglia
        self.righe = 7
        self.colonne = 14
        self.bordo=-20
        
        print(f"Creazione griglia {self.righe}x{self.colonne}")
        
        # Dimensioni delle tessere
        self.tessera_width = larghezza_schermo // self.colonne
        self.tessera_height = altezza_schermo // self.righe
        
        print(f"Dimensione tessere: {self.tessera_width}x{self.tessera_height} pixel")
        
        # Creazione della matrice di tessere
        self.matrice = []
        self.stato_tessere = []  # Matrice di valori booleani (True = a galla, False = affondata)
        
        try:
            # Inizializzazione delle matrici
            for i in range(self.righe):
                riga_tessere = []
                riga_stato = []
                for j in range(self.colonne):
                    x = j * self.tessera_width
                    y = i * self.tessera_height
                    tessera = Tessera(larghezza_schermo, altezza_schermo, immagine, schermo, x, y, 0)
                    riga_tessere.append(tessera)
                    riga_stato.append(True)  # Inizialmente tutte le tessere sono a galla
                self.matrice.append(riga_tessere)
                self.stato_tessere.append(riga_stato)
            
            print(f"Matrice di tessere creata con successo: {self.righe}x{self.colonne}")
            
            # Gruppo di sprite per tutte le tessere
            self.tessere_gruppo = pygame.sprite.Group()
            for riga in self.matrice:
                for tessera in riga:
                    self.tessere_gruppo.add(tessera)
            
            print(f"Gruppo di {len(self.tessere_gruppo)} tessere creato con successo")
        
        except Exception as e:
            print(f"ERRORE durante la creazione della matrice: {e}")
   
    def get_tessera_pos(self, pos_x, pos_y):
        """Converte le coordinate in pixel nella posizione della tessera nella matrice"""
        try:
            col = int(pos_x // self.tessera_width)
            riga = int(pos_y // self.tessera_height)
            
            # Assicuriamoci che le coordinate siano all'interno della matrice
            col = max(0, min(self.colonne - 1, col))
            riga = max(0, min(self.righe - 1, riga))
            
            return riga, col
        except Exception as e:
            print(f"ERRORE in get_tessera_pos: {e}")
            return 0, 0
   
    def main(self, pos_pinguino1, pos_pinguino2):
        """
        Aggiorna lo stato delle tessere in base alla posizione dei pinguini
        pos_pinguino1 e pos_pinguino2 sono tuple (x, y) con le coordinate in pixel
        """
        try:
            
            # Trova la posizione delle tessere corrispondenti ai pinguini
            riga1, col1 = self.get_tessera_pos(pos_pinguino1[0], pos_pinguino1[1])
            riga2, col2 = self.get_tessera_pos(pos_pinguino2[0], pos_pinguino2[1])
            
            
            # Aggiorna lo stato delle tessere calpestate dai pinguini
            if 0 <= riga1 < self.righe and 0 <= col1 < self.colonne:
                
                self.matrice[riga1][col1].affonda()
                self.stato_tessere[riga1][col1] = False
            
            if 0 <= riga2 < self.righe and 0 <= col2 < self.colonne:
                self.stato_tessere[riga2][col2] = False
                self.matrice[riga2][col2].affonda()
            else:
                pinguino2_caduto = not self.stato_tessere[riga2][col2] and self.matrice[riga2][col2].alpha < 50
            
            # Aggiorna tutte le tessere
            self.tessere_gruppo.update()
            
            # Disegna tutte le tessere
            self.tessere_gruppo.draw(self.schermo)
            
            # Controlla se un pinguino è su una tessera affondata (per rilevare le cadute)
            pinguino1_caduto = False
            pinguino2_caduto = False
            
            if 0 <= riga1 < self.righe and 0 <= col1 < self.colonne:
                pinguino1_caduto = not self.stato_tessere[riga1][col1] and self.matrice[riga1][col1].alpha < 50
            
            if pos_pinguino1[0] < 0:
                pinguino1_caduto = True
            elif pos_pinguino1[0] > self.larghezza_schermo-self.bordo:
                pinguino1_caduto = True
            if pos_pinguino1[1] < self.bordo:
                pinguino1_caduto = True
            elif pos_pinguino1[1] > self.altezza_schermo-self.bordo:
                pinguino1_caduto = True

            
            if 0 <= riga2 < self.righe and 0 <= col2 < self.colonne:
                pinguino2_caduto = not self.stato_tessere[riga2][col2] and self.matrice[riga2][col2].alpha < 50
            
            if pos_pinguino2[0] < self.bordo:
                pinguino2_caduto = True
            elif pos_pinguino2[0] > self.larghezza_schermo-self.bordo:
                pinguino2_caduto = True
            if pos_pinguino2[1] < self.bordo:
                pinguino2_caduto = True
            elif pos_pinguino2[1] > self.altezza_schermo-self.bordo:
                pinguino2_caduto = True

            if pinguino1_caduto:
                print("PINGUINO 1 È CADUTO!")
            if pinguino2_caduto:
                print("PINGUINO 2 È CADUTO!")

            return pinguino1_caduto, pinguino2_caduto
        
        except Exception as e:
            print(f"ERRORE in MatriceTessere.main: {e}")
            return False, False
   
    def aggiorna_stato(self):
        """
        Aggiorna lo stato delle tessere in base alla loro opacità
        Se una tessera è completamente visibile, il suo stato diventa True (a galla)
        """
        try:
            for i in range(self.righe):
                for j in range(self.colonne):
                    tessera = self.matrice[i][j]
                    # Se l'opacità è quasi al massimo, la tessera è tornata a galla
                    if tessera.alpha > 250:
                        self.stato_tessere[i][j] = True
        except Exception as e:
            print(f"ERRORE in aggiorna_stato: {e}")